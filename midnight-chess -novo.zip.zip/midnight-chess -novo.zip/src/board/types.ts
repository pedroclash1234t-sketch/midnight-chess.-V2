import type { Color, Square } from '../engine/chessLib'

/**
 * Contract between the app and whichever board widget draws the position.
 * The board never decides legality: it shows `dests` and reports attempts via
 * `onMove`; the rules engine has the last word. Swapping Chessground for
 * another widget (e.g. an MIT-licensed one) only needs a new implementation.
 */
export interface BoardProps {
  fen: string
  orientation: Color
  turn: Color
  lastMove: readonly [Square, Square] | null
  check: boolean
  dests: ReadonlyMap<Square, Square[]>
  interactive: boolean
  reducedMotion: boolean
  /** Bump to force the board back to `fen` (e.g. after a cancelled promotion). */
  resyncToken: number
  label: string
  /**
   * 'accepted': state changed; 'rejected': snap the piece back;
   * 'pending': waiting for the user (promotion), keep the piece where it is.
   */
  onMove(from: Square, to: Square): 'accepted' | 'rejected' | 'pending'
}
