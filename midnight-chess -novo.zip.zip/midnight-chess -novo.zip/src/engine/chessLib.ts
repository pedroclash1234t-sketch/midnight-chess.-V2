/**
 * Single import point for the rules library.
 * The app never imports chess.js anywhere else, so swapping the vendored copy
 * for the npm package (`chess.js@1.4.0`) is a one-line change here.
 */
export { Chess, SQUARES } from '../../vendor/chess.js/chess'
export type { Square, Color, PieceSymbol, Move } from '../../vendor/chess.js/chess'
