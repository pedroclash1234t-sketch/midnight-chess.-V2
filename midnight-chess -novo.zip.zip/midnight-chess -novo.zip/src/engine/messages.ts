import type { Color } from './chessLib'
import type { EndReason, Outcome } from './types'
import type { Players } from './session'
import { CATEGORY_LABEL, categoryOf, formatControl } from './clock'
import type { TimeControl } from './clock'

export const colorName = (c: Color) => (c === 'w' ? 'brancas' : 'pretas')

const REASON_LABEL: Record<EndReason, string> = {
  checkmate: 'Xeque-mate',
  stalemate: 'Afogamento',
  'insufficient-material': 'Material insuficiente',
  'fivefold-repetition': 'Repetição quíntupla',
  'seventy-five-move': 'Regra dos 75 lances',
  resignation: 'Desistência',
  agreement: 'Empate por acordo',
  'threefold-claimed': 'Repetição tripla reivindicada',
  'fifty-move-claimed': 'Regra dos 50 lances reivindicada',
  timeout: 'Tempo esgotado',
  'timeout-insufficient': 'Tempo esgotado, sem material para mate',
  recorded: 'Resultado do PGN',
}

/** "Blitz 3+2" */
export const describeControl = (c: TimeControl) => `${CATEGORY_LABEL[categoryOf(c)]} ${formatControl(c)}`

export const reasonLabel = (r: EndReason) => REASON_LABEL[r]

/** "Vitória das brancas" / "Vitória das pretas" / "Empate". */
export function resultLabel(o: Pick<Outcome, 'result'>): string {
  if (o.result === '1-0') return 'Vitória das brancas'
  if (o.result === '0-1') return 'Vitória das pretas'
  return 'Empate'
}

/** One-line headline for the end-of-game banner. */
export function describeOutcome(o: Outcome, players?: Players): string {
  const who = (c: Color) => (players ? players[c] : colorName(c))
  switch (o.reason) {
    case 'checkmate':
      return `Xeque-mate. ${resultLabel(o)}.`
    case 'resignation': {
      const loser: Color = o.winner === 'w' ? 'b' : 'w'
      return `${who(loser)} desistiu. ${resultLabel(o)}.`
    }
    case 'stalemate':
      return 'Afogamento: o jogador da vez não tem lances legais. Empate.'
    case 'insufficient-material':
      return 'Material insuficiente para dar xeque-mate. Empate.'
    case 'fivefold-repetition':
      return 'A mesma posição apareceu cinco vezes. Empate.'
    case 'seventy-five-move':
      return '75 lances sem captura nem avanço de peão. Empate.'
    case 'agreement':
      return 'Empate por acordo.'
    case 'threefold-claimed':
      return 'Empate reivindicado por repetição tripla.'
    case 'fifty-move-claimed':
      return 'Empate reivindicado pela regra dos 50 lances.'
    case 'timeout':
      return `${who(o.flagged ?? (o.winner === 'w' ? 'b' : 'w'))} ficou sem tempo. ${resultLabel(o)}.`
    case 'timeout-insufficient':
      return `${who(o.flagged ?? 'w')} ficou sem tempo, mas o adversário não tem material para dar xeque-mate. Empate.`
    case 'recorded':
      return `Resultado informado no PGN importado. ${resultLabel(o)}.`
  }
}

export const resultShort = (o: Pick<Outcome, 'result'>): string =>
  o.result === '1/2-1/2' ? '½–½' : o.result === '1-0' ? '1–0' : '0–1'

/** The reason alone (the headline already says who won), e.g. "Xeque-mate." */
export function outcomeDetail(o: Outcome, players?: Players): string {
  const who = (c: Color) => (players ? players[c] : colorName(c))
  switch (o.reason) {
    case 'checkmate':
      return 'Xeque-mate.'
    case 'resignation':
      return `${who(o.winner === 'w' ? 'b' : 'w')} desistiu.`
    case 'stalemate':
      return 'Afogamento: o jogador da vez não tem lances legais.'
    case 'insufficient-material':
      return 'Material insuficiente para dar xeque-mate.'
    case 'fivefold-repetition':
      return 'A mesma posição apareceu cinco vezes.'
    case 'seventy-five-move':
      return '75 lances sem captura nem avanço de peão.'
    case 'agreement':
      return 'Os jogadores concordaram com o empate.'
    case 'threefold-claimed':
      return 'Empate reivindicado: a mesma posição apareceu três vezes.'
    case 'fifty-move-claimed':
      return 'Empate reivindicado: 50 lances sem captura nem avanço de peão.'
    case 'timeout':
      return `${who(o.flagged ?? (o.winner === 'w' ? 'b' : 'w'))} ficou sem tempo.`
    case 'timeout-insufficient':
      return `${who(o.flagged ?? 'w')} ficou sem tempo, mas o adversário não tem material para dar xeque-mate.`
    case 'recorded':
      return 'Resultado informado no PGN importado.'
  }
}
