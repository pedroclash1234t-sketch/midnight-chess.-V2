import { Chess } from './chessLib'
import { reasonLabel, resultLabel } from './messages'
import { analyzeMoves } from './position'
import { cleanName } from './session'
import type { GameResult, MoveRecord, PromotionPiece } from './types'

/** Longest PGN text accepted (characters). */
export const MAX_PGN_CHARS = 200_000
const MAX_PLIES = 2000

export interface ImportedGame {
  white: string
  black: string
  result: GameResult
  moves: MoveRecord[]
  /** From the Date header when it is a complete date; null otherwise. */
  startedAt: string | null
}

export type ImportResult = { ok: true; game: ImportedGame } | { ok: false; error: string }

const fail = (error: string): { ok: false; error: string } => ({ ok: false, error })

const STANDARD_FEN = new Chess().fen()
const RESULTS: readonly string[] = ['1-0', '0-1', '1/2-1/2']
/** Result token at the very end of the movetext (optionally followed by a {comment}). */
const END_MARKER = /(1-0|0-1|1\/2-1\/2|\*)\s*(?:\{[^}]*\}\s*)?$/
const HEADER_RESULT = /\[Result\s+"([^"]*)"\s*\]/i

function explain(e: unknown): string {
  const msg = e instanceof Error ? e.message : String(e)
  const illegal = /Invalid move in PGN: (.+)/.exec(msg)
  if (illegal) return `Lance ilegal ou ambíguo no PGN: ${illegal[1]}.`
  return `O texto não é um PGN válido (${msg}).`
}

function dateOf(value: string | undefined): string | null {
  const m = /^(\d{4})\.(\d{2})\.(\d{2})$/.exec(value ?? '')
  if (!m) return null
  const d = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]), 12))
  return Number.isNaN(d.getTime()) || d.getUTCMonth() !== Number(m[2]) - 1 ? null : d.toISOString()
}

const nameOf = (h: string | undefined, fallback: string) => cleanName(!h || h === '?' ? '' : h, fallback)

/**
 * Validates a PGN and turns it into a game that can be added to the history. Pure: it never
 * touches the game in progress or storage. Only finished standard-chess games from the
 * standard start position are accepted, every move must be legal in chess.js, and the stated
 * result must not contradict the final position.
 */
export function importPgn(raw: string): ImportResult {
  const text = raw.replace(/^\uFEFF/, '').trim()
  if (!text) return fail('Cole o texto do PGN ou escolha um arquivo.')
  if (text.length > MAX_PGN_CHARS) return fail('O PGN é grande demais (limite de 200 mil caracteres).')
  if ((text.match(/^[ \t]*\[Event\s/gm) ?? []).length > 1) return fail('O texto tem mais de uma partida. Importe uma de cada vez.')

  const chess = new Chess()
  try {
    chess.loadPgn(text)
  } catch (e) {
    return fail(explain(e))
  }
  const headers = chess.getHeaders()
  if (headers.FEN && headers.FEN !== STANDARD_FEN) return fail('PGN com posição inicial personalizada ainda não é suportado.')
  if (headers.Variant && headers.Variant.toLowerCase() !== 'standard') return fail(`A variante "${headers.Variant}" não é suportada: só xadrez padrão.`)

  const moves: MoveRecord[] = chess.history({ verbose: true }).map((m) => {
    const rec: MoveRecord = { san: m.san, from: m.from, to: m.to }
    if (m.promotion) rec.promotion = m.promotion as PromotionPiece
    return rec
  })
  if (moves.length === 0) return fail('O PGN não tem nenhum lance.')
  if (moves.length > MAX_PLIES) return fail('O PGN tem lances demais.')

  // chess.js lets the end marker silently override the header, so a conflict is detected here
  const fromHeader = HEADER_RESULT.exec(text)?.[1] ?? null
  const fromMarker = END_MARKER.exec(text)?.[1] ?? null
  if (fromHeader && fromMarker && fromHeader !== fromMarker) {
    return fail(`O resultado do cabeçalho (${fromHeader}) é diferente do marcador no fim dos lances (${fromMarker}).`)
  }
  const stated = fromMarker ?? fromHeader
  if (!stated || stated === '*') return fail('O PGN não informa o resultado. Só partidas concluídas podem ser importadas.')
  if (!RESULTS.includes(stated)) return fail(`Resultado inválido no PGN: ${stated}.`)
  const result = stated as GameResult

  const end = analyzeMoves(moves).outcome
  if (end && end.result !== result) {
    return fail(`A posição final é ${reasonLabel(end.reason).toLowerCase()} (${resultLabel(end).toLowerCase()}), mas o PGN informa ${result}.`)
  }

  return {
    ok: true,
    game: {
      white: nameOf(headers.White, 'Brancas'),
      black: nameOf(headers.Black, 'Pretas'),
      result,
      moves,
      startedAt: dateOf(headers.Date),
    },
  }
}
