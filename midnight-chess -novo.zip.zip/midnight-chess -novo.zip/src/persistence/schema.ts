import { LIMITS } from '../engine/clock'
import type { ClockState, PauseKind, TimeControl } from '../engine/clock'
import { analyzeMoves, replay, IllegalMoveError } from '../engine/position'
import { cleanName, MAX_NAME_LENGTH } from '../engine/session'
import type { GameState } from '../engine/session'
import { AUTOMATIC_REASONS, MANUAL_REASONS } from '../engine/types'
import type { EndReason, GameResult, MoveRecord, Outcome } from '../engine/types'
import type { Color, Square } from '../engine/chessLib'

/**
 * Bump when the stored shape changes and add a step to `migrate`.
 * v1: first release. v2: timed games (`session.clock`), `timeControl`, `source`, `flagged`.
 */
export const SCHEMA_VERSION = 2

export interface GameRecord {
  id: string
  startedAt: string
  endedAt: string
  white: string
  black: string
  result: GameResult
  reason: EndReason
  /** Who ran out of time (timeouts only). */
  flagged?: Color
  /** Time control the game was played with, or null for untimed games. */
  timeControl: TimeControl | null
  /** 'played' in this app; 'imported' for games brought in from a PGN. */
  source: 'played' | 'imported'
  /** Half-moves; enough to rebuild the whole game. */
  moves: MoveRecord[]
  /** Number of half-moves. */
  plies: number
  /** Number of full moves (ceil(plies / 2)). */
  moveCount: number
  pgn: string
  finalFen: string
}

export interface StoredSession {
  version: number
  savedAt: string
  /** The finished game of this session already reached the history (so deleting it there is final). */
  archived?: boolean
  session: {
    id: string
    startedAt: string
    players: { w: string; b: string }
    moves: MoveRecord[]
    redo: MoveRecord[]
    orientation: Color
    manualOutcome: Outcome | null
    clock: ClockState | null
  }
}

export interface StoredHistory {
  version: number
  games: unknown[]
}

export type Parsed<T> = { ok: true; value: T } | { ok: false; error: string }

const fail = (error: string): { ok: false; error: string } => ({ ok: false, error })

const isObject = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v)
const SQUARE = /^[a-h][1-8]$/
const isIso = (v: unknown): v is string => typeof v === 'string' && v.length <= 40 && !Number.isNaN(Date.parse(v))
const isId = (v: unknown): v is string => typeof v === 'string' && v.length > 0 && v.length <= 100
const isMs = (v: unknown, max: number): v is number => typeof v === 'number' && Number.isFinite(v) && v >= 0 && v <= max
const RESULTS: readonly string[] = ['1-0', '0-1', '1/2-1/2']
const ALL_REASONS: readonly string[] = [...AUTOMATIC_REASONS, ...MANUAL_REASONS]
const PAUSES: readonly string[] = ['manual', 'auto', 'restore']
const TIMEOUT_REASONS: readonly EndReason[] = ['timeout', 'timeout-insufficient']

function parseMove(v: unknown): MoveRecord | null {
  if (!isObject(v)) return null
  const { san, from, to, promotion } = v
  if (typeof san !== 'string' || san.length === 0 || san.length > 12) return null
  if (typeof from !== 'string' || !SQUARE.test(from)) return null
  if (typeof to !== 'string' || !SQUARE.test(to)) return null
  if (promotion !== undefined && !(promotion === 'q' || promotion === 'r' || promotion === 'b' || promotion === 'n')) return null
  const rec: MoveRecord = { san, from: from as Square, to: to as Square }
  if (promotion !== undefined) rec.promotion = promotion
  return rec
}

function parseMoves(v: unknown, label: string): Parsed<MoveRecord[]> {
  if (!Array.isArray(v) || v.length > 2000) return fail(`${label}: lista de lances inválida`)
  const out: MoveRecord[] = []
  for (const item of v) {
    const m = parseMove(item)
    if (!m) return fail(`${label}: lance inválido`)
    out.push(m)
  }
  return { ok: true, value: out }
}

function parseOutcome(v: unknown): Parsed<Outcome> {
  if (!isObject(v)) return fail('desfecho inválido')
  if (typeof v.result !== 'string' || !RESULTS.includes(v.result)) return fail('resultado inválido')
  if (typeof v.reason !== 'string' || !ALL_REASONS.includes(v.reason)) return fail('motivo de término inválido')
  const out: Outcome = { result: v.result as GameResult, reason: v.reason as EndReason }
  if (v.winner === 'w' || v.winner === 'b') out.winner = v.winner
  if (v.flagged === 'w' || v.flagged === 'b') out.flagged = v.flagged
  if (TIMEOUT_REASONS.includes(out.reason)) {
    if (!out.flagged) return fail('tempo esgotado sem indicar quem')
    if (out.reason === 'timeout' && !(out.result !== '1/2-1/2' && out.winner && out.winner !== out.flagged)) return fail('tempo esgotado inconsistente')
    if (out.reason === 'timeout-insufficient' && out.result !== '1/2-1/2') return fail('tempo esgotado inconsistente')
  }
  return { ok: true, value: out }
}

function parseNames(v: unknown): Parsed<{ w: string; b: string }> {
  if (!isObject(v) || typeof v.w !== 'string' || typeof v.b !== 'string') return fail('nomes dos jogadores inválidos')
  if (v.w.length > MAX_NAME_LENGTH * 4 || v.b.length > MAX_NAME_LENGTH * 4) return fail('nomes dos jogadores inválidos')
  return { ok: true, value: { w: cleanName(v.w, 'Brancas'), b: cleanName(v.b, 'Pretas') } }
}

export function parseControl(v: unknown): Parsed<TimeControl> {
  if (!isObject(v)) return fail('controle de tempo inválido')
  const { baseMs, incrementMs } = v
  if (!isMs(baseMs, LIMITS.maxBaseMin * 60_000) || baseMs < 10_000) return fail('tempo base inválido')
  if (!isMs(incrementMs, LIMITS.maxIncrementSec * 1000)) return fail('acréscimo inválido')
  return { ok: true, value: { baseMs, incrementMs } }
}

function parseClock(v: unknown, plies: number): Parsed<ClockState> {
  if (!isObject(v)) return fail('relógio inválido')
  const control = parseControl(v.control)
  if (!control.ok) return control
  if (!isObject(v.remaining)) return fail('tempos restantes inválidos')
  const max = control.value.baseMs + control.value.incrementMs * (plies + 1)
  const { w, b } = v.remaining
  if (!isMs(w, max) || !isMs(b, max)) return fail('tempos restantes inválidos')
  let since: number | null = null
  if (v.since !== null && v.since !== undefined) {
    if (!isMs(v.since, 8.64e15)) return fail('instante do relógio inválido')
    since = v.since
  }
  let paused: PauseKind | null = null
  if (v.paused !== null && v.paused !== undefined) {
    if (typeof v.paused !== 'string' || !PAUSES.includes(v.paused)) return fail('pausa inválida')
    paused = v.paused as PauseKind
  }
  if (since !== null && (paused !== null || plies === 0)) return fail('relógio em andamento inconsistente')
  return { ok: true, value: { control: control.value, remaining: { w, b }, since, paused } }
}

/** Replays `moves` through chess.js: the stored line must be a legal game. */
function checkReplay(moves: MoveRecord[], label: string): Parsed<true> {
  try {
    replay(moves)
    return { ok: true, value: true }
  } catch (e) {
    return fail(`${label}: ${e instanceof IllegalMoveError ? e.message : 'não foi possível reproduzir os lances'}`)
  }
}

export function parseSession(raw: unknown): Parsed<GameState> {
  if (!isObject(raw) || !isObject(raw.session)) return fail('formato inesperado')
  const s = raw.session
  if (!isId(s.id) || !isIso(s.startedAt)) return fail('identificação da partida inválida')
  const players = parseNames(s.players)
  if (!players.ok) return players
  const moves = parseMoves(s.moves, 'lances')
  if (!moves.ok) return moves
  const redo = parseMoves(s.redo ?? [], 'refazer')
  if (!redo.ok) return redo
  if (s.orientation !== 'w' && s.orientation !== 'b') return fail('orientação inválida')
  let manualOutcome: Outcome | null = null
  if (s.manualOutcome !== null && s.manualOutcome !== undefined) {
    const o = parseOutcome(s.manualOutcome)
    if (!o.ok) return o
    if (!MANUAL_REASONS.includes(o.value.reason) || o.value.reason === 'recorded') return fail('desfecho manual inválido')
    manualOutcome = o.value
  }
  let clock: ClockState | null = null
  if (s.clock !== null && s.clock !== undefined) {
    const c = parseClock(s.clock, moves.value.length)
    if (!c.ok) return c
    clock = c.value
    if (redo.value.length > 0) return fail('partida com relógio não tem lances para refazer')
  } else if (manualOutcome && TIMEOUT_REASONS.includes(manualOutcome.reason)) {
    return fail('tempo esgotado em partida sem relógio')
  }
  const line = checkReplay(moves.value, 'lances')
  if (!line.ok) return line
  // The redo stack must continue the line legally (its last item is played first).
  const redoLine = checkReplay([...moves.value, ...[...redo.value].reverse()], 'refazer')
  if (!redoLine.ok) return redoLine
  const auto = analyzeMoves(moves.value).outcome
  if (manualOutcome && auto) return fail('partida já terminada antes do desfecho manual')
  if (manualOutcome && redo.value.length > 0) return fail('partida terminada com lances para refazer')
  // a finished game never has a running clock, whatever was stored
  if (clock && (manualOutcome || auto) && clock.since !== null) clock = { ...clock, since: null }
  const state: GameState = {
    id: s.id,
    startedAt: s.startedAt,
    players: players.value,
    moves: moves.value,
    redo: redo.value,
    viewIndex: moves.value.length,
    orientation: s.orientation,
    manualOutcome,
    clock,
  }
  return { ok: true, value: state }
}

export function parseGameRecord(raw: unknown): Parsed<GameRecord> {
  if (!isObject(raw)) return fail('registro inválido')
  if (!isId(raw.id)) return fail('identificador inválido')
  if (!isIso(raw.startedAt) || !isIso(raw.endedAt)) return fail('datas inválidas')
  if (typeof raw.white !== 'string' || typeof raw.black !== 'string') return fail('nomes inválidos')
  if (typeof raw.pgn !== 'string' || raw.pgn.length > 200_000) return fail('PGN inválido')
  if (typeof raw.finalFen !== 'string') return fail('posição final inválida')
  if (raw.source !== 'played' && raw.source !== 'imported') return fail('origem da partida inválida')
  let timeControl: TimeControl | null = null
  if (raw.timeControl !== null && raw.timeControl !== undefined) {
    const tc = parseControl(raw.timeControl)
    if (!tc.ok) return tc
    timeControl = tc.value
  }
  // records keep only the result; the winner follows from it
  const winner = raw.result === '1-0' ? 'w' : raw.result === '0-1' ? 'b' : undefined
  const o = parseOutcome({ result: raw.result, reason: raw.reason, winner, flagged: raw.flagged })
  if (!o.ok) return o
  if (TIMEOUT_REASONS.includes(o.value.reason) && timeControl === null) return fail('tempo esgotado em partida sem relógio')
  if (o.value.reason === 'recorded' && raw.source !== 'imported') return fail('resultado de PGN em partida jogada aqui')
  const moves = parseMoves(raw.moves, 'lances')
  if (!moves.ok) return moves
  const line = checkReplay(moves.value, 'lances')
  if (!line.ok) return line
  const end = analyzeMoves(moves.value)
  if (raw.plies !== moves.value.length || raw.moveCount !== Math.ceil(moves.value.length / 2)) {
    return fail('contagem de lances inconsistente')
  }
  if (end.fen !== raw.finalFen) return fail('posição final não confere com os lances')
  const reason = o.value.reason
  if (AUTOMATIC_REASONS.includes(reason)) {
    if (!end.outcome || end.outcome.reason !== reason || end.outcome.result !== o.value.result) {
      return fail('resultado não confere com os lances')
    }
  } else if (end.outcome) {
    return fail('desfecho manual em partida já terminada')
  }
  const record: GameRecord = {
    id: raw.id,
    startedAt: raw.startedAt,
    endedAt: raw.endedAt,
    white: cleanName(raw.white, 'Brancas'),
    black: cleanName(raw.black, 'Pretas'),
    result: o.value.result,
    reason,
    timeControl,
    source: raw.source,
    moves: moves.value,
    plies: moves.value.length,
    moveCount: Math.ceil(moves.value.length / 2),
    pgn: raw.pgn,
    finalFen: raw.finalFen,
  }
  if (o.value.flagged) record.flagged = o.value.flagged
  return { ok: true, value: record }
}

/** v1 -> v2: sessions gain `clock: null`; history records gain `timeControl: null` and `source: 'played'`. */
function migrateV1(data: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = { ...data, version: 2 }
  if (isObject(data.session)) out.session = { ...data.session, clock: null }
  if (Array.isArray(data.games)) {
    out.games = data.games.map((g) => (isObject(g) ? { timeControl: null, source: 'played', ...g } : g))
  }
  return out
}

/**
 * Brings stored data of an older schema up to SCHEMA_VERSION, one step per version.
 * Nothing is dropped: fields are only added.
 */
export function migrate(data: Record<string, unknown>): Parsed<Record<string, unknown>> {
  const version = data.version
  if (typeof version !== 'number' || !Number.isInteger(version) || version < 1) return fail('versão ausente ou inválida')
  if (version > SCHEMA_VERSION) return fail(`dados da versão ${version}, mais nova que a suportada (${SCHEMA_VERSION})`)
  let out = data
  if (version === 1) out = migrateV1(out)
  return { ok: true, value: out }
}
