import type { Color, Square } from '../engine/chessLib'
import type { TimeControl } from '../engine/clock'
import type { Analysis } from '../engine/position'
import {
  agreeDraw,
  applyTimeout,
  canLeaveGame,
  canPlay,
  canRedo,
  canUndo,
  claimDraw,
  createGame,
  flip,
  hasProgress,
  isFinished,
  isPaused,
  liveAnalysis,
  navigate,
  outcomeOf,
  pauseClock,
  playMove,
  redo,
  resign,
  restoreClock,
  resumeClock,
  undo,
  viewAnalysis,
} from '../engine/session'
import type { GameEnv, GameState, MoveError, NavTarget, Players } from '../engine/session'
import type { Outcome, PromotionPiece } from '../engine/types'
import { buildRecord, computeStats } from '../persistence/record'
import type { Stats } from '../persistence/record'
import type { GameRecord } from '../persistence/schema'
import type { Persistence, SaveResult } from '../persistence/storage'
import { analyzeMoves } from '../engine/position'
import type { ImportedGame } from '../engine/pgnImport'
import { buildPgn } from '../persistence/record'

export type NoticeKind = 'info' | 'success' | 'warning' | 'error'

export interface Notice {
  id: number
  kind: NoticeKind
  text: string
}

export interface Snapshot {
  game: GameState
  /** Position shown on the board (follows the browsing cursor). */
  view: Analysis
  /** Position after the last played move. */
  live: Analysis
  outcome: Outcome | null
  finished: boolean
  canPlay: boolean
  canUndo: boolean
  canRedo: boolean
  canClaimDraw: boolean
  /** True when moves exist and the game is still running (leaving it loses progress). */
  hasProgress: boolean
  /** False while a timed game is in progress: new game / restart are refused. */
  canLeave: boolean
  paused: boolean
  history: GameRecord[]
  stats: Stats
  notice: Notice | null
  storage: { available: boolean; error: string | null }
}

/** 'duplicate': the same move arrived twice in a row (double tap); ignored without any message. */
export type MoveOutcome = 'ok' | 'promotion-required' | 'rejected' | 'duplicate'

const MOVE_ERROR_TEXT: Record<MoveError, string> = {
  illegal: 'Esse lance não é permitido.',
  'promotion-required': 'Escolha a peça da promoção.',
  'game-over': 'A partida terminou. Comece uma nova partida para jogar.',
  'not-live': 'Volte ao último lance para continuar jogando.',
  paused: 'A partida está pausada. Toque em Retomar para continuar.',
  'time-over': 'Tempo esgotado.',
}

/** A repeat of the move just played, arriving within this window, is a double tap. */
const DUPLICATE_WINDOW_MS = 600

export class GameStore {
  private state: GameState
  private history: GameRecord[]
  private snapshot!: Snapshot
  private readonly listeners = new Set<() => void>()
  private noticeSeq = 0
  private notice: Notice | null = null
  private saveError: string | null = null
  /** The finished game of the current session is already in the history. */
  private archived = false
  private lastAccepted: { from: Square; to: Square; at: number; plies: number } | null = null

  constructor(
    private readonly persistence: Persistence,
    private readonly env: GameEnv,
  ) {
    const loadedHistory = persistence.loadHistory()
    this.history = loadedHistory.games
    const messages = [...loadedHistory.warnings]

    const current = persistence.loadCurrent()
    let restoredPause = false
    if (current.status === 'ok') {
      const restored = restoreClock(current.state)
      restoredPause = restored !== current.state
      this.state = restored
      this.archived = current.archived
    } else {
      this.state = createGame(env)
      if (current.status === 'invalid') messages.push(current.message)
    }
    if (messages.length > 0) this.notice = { id: ++this.noticeSeq, kind: 'warning', text: messages.join(' ') }
    if (!persistence.available) {
      this.saveError = 'Este navegador bloqueou o armazenamento: a partida não será recuperada ao recarregar.'
    }
    // A finished game restored from disk may not have reached the history yet
    // (the tab closed between the writes). `archived` stops a game the user
    // deleted from the history from coming back on the next load.
    this.archiveIfFinished()
    if (current.status === 'invalid' || restoredPause) this.recordSave(this.persistence.saveCurrent(this.state, this.archived))
    this.rebuild()
  }

  // ---- subscription (useSyncExternalStore) -------------------------------

  subscribe = (listener: () => void): (() => void) => {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }

  getSnapshot = (): Snapshot => this.snapshot

  /** Current instant in ms (the clock's time source, injectable in tests). */
  nowMs = (): number => this.env.now().getTime()

  // ---- internals ----------------------------------------------------------

  private rebuild() {
    const s = this.state
    const live = liveAnalysis(s)
    this.snapshot = {
      game: s,
      view: viewAnalysis(s),
      live,
      outcome: outcomeOf(s),
      finished: isFinished(s),
      canPlay: canPlay(s),
      canUndo: canUndo(s),
      canRedo: canRedo(s),
      canClaimDraw: !isFinished(s) && (live.claim.threefold || live.claim.fiftyMove),
      hasProgress: hasProgress(s),
      canLeave: canLeaveGame(s),
      paused: isPaused(s),
      history: this.history,
      stats: computeStats(this.history),
      notice: this.notice,
      storage: { available: this.persistence.available, error: this.saveError },
    }
    for (const l of this.listeners) l()
  }

  private recordSave(result: SaveResult) {
    if (result.ok) {
      if (this.persistence.available) this.saveError = null
    } else {
      this.saveError = result.error
    }
  }

  private archiveIfFinished() {
    const outcome = outcomeOf(this.state)
    if (!outcome || this.archived) return
    // 1) the finished session is on disk (not archived yet), 2) the record, 3) the "archived" mark
    this.recordSave(this.persistence.saveCurrent(this.state, false))
    const record = buildRecord(this.state, outcome, this.env.now())
    this.history = [record, ...this.history.filter((g) => g.id !== record.id)].sort((a, b) => b.endedAt.localeCompare(a.endedAt))
    const saved = this.persistence.upsertGame(record)
    this.recordSave(saved)
    this.archived = true
  }

  private commit(next: GameState) {
    if (next === this.state) return
    if (next.id !== this.state.id) {
      this.archived = false
      this.lastAccepted = null
    }
    this.state = next
    this.archiveIfFinished()
    this.recordSave(this.persistence.saveCurrent(next, this.archived))
    this.rebuild()
  }

  private say(kind: NoticeKind, text: string) {
    this.notice = { id: ++this.noticeSeq, kind, text }
  }

  /**
   * Applies a flag fall if one has happened. Called before every action and by the UI
   * timer, so the result never depends on which of the two notices the timeout first.
   * Returns true when the game was just ended on time.
   */
  private syncClock(now: number): boolean {
    const next = applyTimeout(this.state, now)
    if (next === this.state) return false
    const flagged = next.manualOutcome?.flagged ?? 'w'
    this.say('warning', `Tempo esgotado: ${next.players[flagged]} ficou sem tempo.`)
    this.commit(next)
    return true
  }

  // ---- actions ------------------------------------------------------------

  move(from: Square, to: Square, promotion?: PromotionPiece): MoveOutcome {
    const now = this.nowMs()
    if (this.syncClock(now)) return 'rejected'
    const result = playMove(this.state, { from, to, promotion }, now)
    if (result.ok) {
      this.notice = null
      this.lastAccepted = { from, to, at: now, plies: result.state.moves.length }
      this.commit(result.state)
      return 'ok'
    }
    if (result.error === 'promotion-required') return 'promotion-required'
    const last = this.lastAccepted
    if (
      result.error === 'illegal' &&
      last &&
      last.from === from &&
      last.to === to &&
      last.plies === this.state.moves.length &&
      now - last.at >= 0 &&
      now - last.at < DUPLICATE_WINDOW_MS
    ) {
      return 'duplicate'
    }
    this.say('error', MOVE_ERROR_TEXT[result.error])
    this.rebuild()
    return 'rejected'
  }

  undo() {
    this.commit(undo(this.state))
  }

  redo() {
    this.commit(redo(this.state))
  }

  navigate(target: NavTarget) {
    this.commit(navigate(this.state, target))
  }

  flip() {
    this.commit(flip(this.state))
  }

  resign(color: Color) {
    const now = this.nowMs()
    if (this.syncClock(now)) return
    this.commit(resign(this.state, color, now))
  }

  agreeDraw() {
    const now = this.nowMs()
    if (this.syncClock(now)) return
    this.commit(agreeDraw(this.state, now))
  }

  claimDraw() {
    const now = this.nowMs()
    if (this.syncClock(now)) return
    const next = claimDraw(this.state, now)
    if (next === this.state) {
      this.say('warning', 'Nenhum empate pode ser reivindicado nesta posição.')
      this.rebuild()
      return
    }
    this.commit(next)
  }

  // ---- clock ----------------------------------------------------------------

  /** Called by the UI timer while a clock is running. Returns true if time just ran out. */
  tick(): boolean {
    return this.syncClock(this.nowMs())
  }

  /** Manual pause (only the slower modes allow it). */
  pause() {
    const now = this.nowMs()
    if (this.syncClock(now)) return
    const next = pauseClock(this.state, now, 'manual')
    if (next === this.state) {
      this.say('warning', 'A pausa manual só existe nos modos Rápido e Clássico, e depois do primeiro lance.')
      this.rebuild()
      return
    }
    this.commit(next)
  }

  /** The app left the foreground (screen locked, app switched, tab hidden): stop the clock. */
  autoPause() {
    const now = this.nowMs()
    if (this.syncClock(now)) return
    this.commit(pauseClock(this.state, now, 'auto'))
  }

  resume() {
    this.commit(resumeClock(this.state, this.nowMs()))
  }

  // ---- new game ---------------------------------------------------------------

  newGame(players?: Partial<Players>, control: TimeControl | null = null) {
    if (!canLeaveGame(this.state)) {
      this.say('warning', 'Partida com relógio em andamento: para encerrá-la, use Desistir ou Empate.')
      this.rebuild()
      return
    }
    this.say('info', 'Nova partida iniciada.')
    this.commit(createGame(this.env, players ?? {}, 'w', control))
  }

  /** Same players and time control, fresh board. */
  restart() {
    this.newGame(this.state.players, this.state.clock ? this.state.clock.control : null)
  }

  /**
   * Adds an imported game to the history. It never touches the game in progress, its clock or
   * its saved copy; a game that is already in the history (same players, result and moves) is refused.
   */
  importGame(game: ImportedGame): { ok: true } | { ok: false; error: string } {
    const same = (a: GameRecord) =>
      a.source === 'imported' &&
      a.white === game.white &&
      a.black === game.black &&
      a.result === game.result &&
      a.moves.length === game.moves.length &&
      a.moves.every((m, i) => m.from === game.moves[i].from && m.to === game.moves[i].to && m.promotion === game.moves[i].promotion)
    if (this.history.some(same)) return { ok: false, error: 'Esta partida já foi importada.' }

    const now = this.env.now()
    const base = createGame(this.env, { w: game.white, b: game.black })
    const state: GameState = { ...base, startedAt: game.startedAt ?? now.toISOString(), moves: game.moves, viewIndex: game.moves.length }
    const auto = analyzeMoves(game.moves).outcome
    const outcome: Outcome = auto ?? { result: game.result, reason: 'recorded' }
    const record: GameRecord = {
      ...buildRecord(state, outcome, now),
      source: 'imported',
      pgn: buildPgn(state, outcome, { event: 'Partida importada', site: 'Midnight Chess (importação)' }),
    }
    const saved = this.persistence.upsertGame(record)
    if (!saved.ok) return { ok: false, error: saved.error }
    this.history = [record, ...this.history.filter((g) => g.id !== record.id)].sort((a, b) => b.endedAt.localeCompare(a.endedAt))
    this.recordSave(saved)
    this.say('success', 'Partida importada.')
    this.rebuild()
    return { ok: true }
  }

  deleteGame(id: string) {
    this.history = this.history.filter((g) => g.id !== id)
    this.recordSave(this.persistence.deleteGame(id))
    this.say('success', 'Partida excluída.')
    this.rebuild()
  }

  dismissNotice(id?: number) {
    if (!this.notice || (id !== undefined && this.notice.id !== id)) return
    this.notice = null
    this.rebuild()
  }

  getState(): GameState {
    return this.state
  }
}
