import { createContext, useContext } from 'react'
import type { GameStore } from '../store/gameStore'

const Ctx = createContext<GameStore | null>(null)

export const StoreProvider = Ctx.Provider

export function useStore(): GameStore {
  const store = useContext(Ctx)
  if (!store) throw new Error('StoreProvider ausente')
  return store
}
