import { useState } from 'react'
import type { FormEvent } from 'react'
import type { TimeControl } from '../../engine/clock'
import type { Color } from '../../engine/chessLib'
import { DEFAULT_PLAYERS, MAX_NAME_LENGTH } from '../../engine/session'
import type { Players } from '../../engine/session'
import type { PromotionPiece } from '../../engine/types'
import { Modal } from './Modal'
import { TimeControlPicker } from './TimeControlPicker'
import { PieceGlyph } from './PieceGlyph'
import type { Role } from './PieceGlyph'

export function ConfirmDialog(props: {
  open: boolean
  title: string
  message: string
  confirmLabel: string
  danger?: boolean
  onConfirm(): void
  onClose(): void
}) {
  return (
    <Modal open={props.open} title={props.title} onClose={props.onClose}>
      <p>{props.message}</p>
      <div className="modal-actions">
        <button type="button" className="btn" onClick={props.onClose}>
          Cancelar
        </button>
        <button
          type="button"
          className={props.danger ? 'btn btn-danger' : 'btn btn-primary'}
          onClick={() => {
            props.onConfirm()
            props.onClose()
          }}
        >
          {props.confirmLabel}
        </button>
      </div>
    </Modal>
  )
}

export function NewGameDialog(props: {
  open: boolean
  players: Players
  control: TimeControl | null
  hasProgress: boolean
  onStart(players: Players, control: TimeControl | null): void
  onClose(): void
}) {
  const [white, setWhite] = useState(props.players.w === DEFAULT_PLAYERS.w ? '' : props.players.w)
  const [black, setBlack] = useState(props.players.b === DEFAULT_PLAYERS.b ? '' : props.players.b)
  const [control, setControl] = useState<TimeControl | null | undefined>(props.control)
  const submit = (e: FormEvent) => {
    e.preventDefault()
    if (control === undefined) return
    props.onStart({ w: white, b: black }, control)
    props.onClose()
  }
  return (
    <Modal open={props.open} title="Nova partida" onClose={props.onClose}>
      <form onSubmit={submit} className="modal-body" style={{ padding: 0 }}>
        {props.hasProgress && <p>A partida em andamento será descartada.</p>}
        <label className="field">
          Jogador das brancas
          <input value={white} maxLength={MAX_NAME_LENGTH} placeholder={DEFAULT_PLAYERS.w} onChange={(e) => setWhite(e.target.value)} />
        </label>
        <label className="field">
          Jogador das pretas
          <input value={black} maxLength={MAX_NAME_LENGTH} placeholder={DEFAULT_PLAYERS.b} onChange={(e) => setBlack(e.target.value)} />
        </label>
        <TimeControlPicker value={props.control} onChange={setControl} />
        <div className="modal-actions">
          <button type="button" className="btn" onClick={props.onClose}>
            Cancelar
          </button>
          <button type="submit" className="btn btn-primary" disabled={control === undefined}>
            Começar partida
          </button>
        </div>
      </form>
    </Modal>
  )
}

export function ResignDialog(props: { open: boolean; players: Players; onResign(c: Color): void; onClose(): void }) {
  return (
    <Modal open={props.open} title="Quem está desistindo?" onClose={props.onClose}>
      <p>O adversário vence a partida. Esta ação não pode ser desfeita.</p>
      <div className="who-btns">
        {(['w', 'b'] as const).map((c) => (
          <button
            key={c}
            type="button"
            className="btn btn-danger"
            onClick={() => {
              props.onResign(c)
              props.onClose()
            }}
          >
            {props.players[c]} ({c === 'w' ? 'brancas' : 'pretas'})
          </button>
        ))}
      </div>
      <div className="modal-actions">
        <button type="button" className="btn" onClick={props.onClose}>
          Cancelar
        </button>
      </div>
    </Modal>
  )
}

const PROMOTIONS: Array<{ piece: PromotionPiece; role: Role; label: string }> = [
  { piece: 'q', role: 'queen', label: 'Dama' },
  { piece: 'r', role: 'rook', label: 'Torre' },
  { piece: 'b', role: 'bishop', label: 'Bispo' },
  { piece: 'n', role: 'knight', label: 'Cavalo' },
]

export function PromotionDialog(props: { open: boolean; color: Color; onChoose(p: PromotionPiece): void; onCancel(): void }) {
  return (
    <Modal open={props.open} title="Promover o peão" onClose={props.onCancel}>
      <div className="promo-grid">
        {PROMOTIONS.map((p) => (
          <button key={p.piece} type="button" className="promo-btn" onClick={() => props.onChoose(p.piece)} aria-label={p.label}>
            <PieceGlyph color={props.color} role={p.role} />
            <span>{p.label}</span>
          </button>
        ))}
      </div>
      <div className="modal-actions">
        <button type="button" className="btn" onClick={props.onCancel}>
          Cancelar lance
        </button>
      </div>
    </Modal>
  )
}

export function HelpDialog(props: { open: boolean; onClose(): void }) {
  return (
    <Modal open={props.open} title="Como jogar" onClose={props.onClose}>
      <ul>
        <li>Toque ou clique numa peça para ver os lances possíveis e depois no destino. Também dá para arrastar.</li>
        <li>As brancas começam e os dois jogadores se revezam no mesmo aparelho.</li>
        <li>Roque: mova o rei duas casas. En passant e promoção acontecem pelo próprio tabuleiro.</li>
        <li>As setas ← → percorrem os lances sem alterar a partida. Desfazer volta um lance de verdade.</li>
        <li>A partida é salva automaticamente neste navegador e as concluídas ficam em Partidas.</li>
      </ul>
      <div className="modal-actions">
        <button type="button" className="btn btn-primary" onClick={props.onClose}>
          Entendi
        </button>
      </div>
    </Modal>
  )
}
