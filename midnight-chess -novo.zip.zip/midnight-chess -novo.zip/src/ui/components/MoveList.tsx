import { useEffect, useRef } from 'react'
import type { MoveRecord } from '../../engine/types'

interface Props {
  moves: readonly MoveRecord[]
  /** Number of half-moves applied on the board (0 = start position). */
  current: number
  onSelect(ply: number): void
}

function keepVisible(container: HTMLElement, el: HTMLElement) {
  const c = container.getBoundingClientRect()
  const r = el.getBoundingClientRect()
  if (r.top < c.top) container.scrollTop -= c.top - r.top
  else if (r.bottom > c.bottom) container.scrollTop += r.bottom - c.bottom
  if (r.left < c.left) container.scrollLeft -= c.left - r.left
  else if (r.right > c.right) container.scrollLeft += r.right - c.right
}

export function MoveList({ moves, current, onSelect }: Props) {
  const box = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const container = box.current
    const active = container?.querySelector<HTMLElement>('[aria-current="step"]')
    if (container && active) keepVisible(container, active)
    else if (container) container.scrollTop = 0
  }, [current, moves.length])

  if (moves.length === 0) {
    return (
      <div className="moves">
        <p className="moves-empty">Os lances aparecem aqui conforme a partida avança.</p>
      </div>
    )
  }

  const rows: number[] = []
  for (let i = 0; i < moves.length; i += 2) rows.push(i)

  const cell = (ply: number) => {
    const m = moves[ply - 1]
    if (!m) return <span className="move-btn" aria-hidden="true" />
    return (
      <button
        type="button"
        className="move-btn num"
        aria-current={current === ply ? 'step' : undefined}
        aria-label={`Lance ${ply}: ${m.san}`}
        onClick={() => onSelect(ply)}
      >
        {m.san}
      </button>
    )
  }

  return (
    <div className="moves" ref={box}>
      <ol className="move-rows" aria-label="Lances da partida">
        {rows.map((i) => (
          <li className="move-row" key={i}>
            <span className="move-num num">{i / 2 + 1}.</span>
            {cell(i + 1)}
            {cell(i + 2)}
          </li>
        ))}
      </ol>
    </div>
  )
}
