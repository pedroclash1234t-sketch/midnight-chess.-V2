import { useEffect, useRef } from 'react'
import type { Color } from '../../engine/chessLib'

export type Role = 'king' | 'queen' | 'rook' | 'bishop' | 'knight' | 'pawn'

/**
 * Draws a piece with the same CSS classes Chessground uses on the board, so the
 * pieces in cards and dialogs always match the ones on the board. The <piece>
 * element is created through the DOM because React does not know that tag.
 */
export function PieceGlyph({ color, role }: { color: Color; role: Role }) {
  const ref = useRef<HTMLSpanElement>(null)
  useEffect(() => {
    const host = ref.current
    if (!host) return
    const el = document.createElement('piece')
    el.className = `${role} ${color === 'w' ? 'white' : 'black'}`
    host.replaceChildren(el)
  }, [color, role])
  return <span ref={ref} className="cg-wrap glyph" aria-hidden="true" />
}
