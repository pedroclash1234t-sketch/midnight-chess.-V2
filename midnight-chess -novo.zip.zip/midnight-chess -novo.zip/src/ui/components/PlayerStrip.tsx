import type { Color } from '../../engine/chessLib'
import type { ClockState } from '../../engine/clock'
import type { Outcome } from '../../engine/types'
import { ClockFace } from './ClockFace'
import { PieceGlyph } from './PieceGlyph'

interface Props {
  color: Color
  name: string
  /** It is this player's turn in the live position. */
  toMove: boolean
  inCheck: boolean
  outcome: Outcome | null
  clock?: ClockState | null
  /** Side to move in the live position (needed by the clock). */
  turn?: Color
  now?: () => number
}

export function PlayerStrip({ color, name, toMove, inCheck, outcome, clock, turn, now }: Props) {
  const active = toMove && !outcome
  const won = outcome?.winner === color
  const drawn = outcome?.result === '1/2-1/2'
  const flagged = outcome?.flagged === color
  return (
    <div className="player" data-active={active} data-color={color} aria-label={`${color === 'w' ? 'Brancas' : 'Pretas'}: ${name}`}>
      <PieceGlyph color={color} role="king" />
      <span className="player-name">{name}</span>
      {inCheck && toMove && !outcome && <span className="tag tag-check">Xeque</span>}
      {active && !clock && <span className="tag tag-turn">Sua vez</span>}
      {won && <span className="tag tag-win">Vitória</span>}
      {drawn && <span className="tag">Empate</span>}
      {flagged && <span className="tag tag-check">Sem tempo</span>}
      {clock && turn && now && <ClockFace clock={clock} turn={turn} color={color} now={now} />}
    </div>
  )
}
