import { useEffect } from 'react'
import type { Notice } from '../../store/gameStore'

export function Toast({ notice, onDismiss }: { notice: Notice | null; onDismiss(id: number): void }) {
  const id = notice?.id
  useEffect(() => {
    if (id === undefined) return
    const t = setTimeout(() => onDismiss(id), 4200)
    return () => clearTimeout(t)
  }, [id, onDismiss])
  if (!notice) return null
  return (
    <div className="toast" data-kind={notice.kind} role={notice.kind === 'error' ? 'alert' : 'status'}>
      {notice.text}
    </div>
  )
}
