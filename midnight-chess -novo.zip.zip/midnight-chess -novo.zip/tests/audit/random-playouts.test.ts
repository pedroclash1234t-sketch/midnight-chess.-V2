/**
 * Auditoria das regras (Fase 1), parte pesada: cruza o que o app deriva (replay a partir
 * da posição inicial) com o que o chess.js informa por um caminho independente
 * (partida sequencial e pilha de desfazer da própria biblioteca) em partidas aleatórias
 * com semente fixa, mais partidas conhecidas (mates, afogamento, repetição).
 * Rodar com `npm run test:audit`.
 */
import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { Chess } from '../../src/engine/chessLib'
import { analyzeMoves } from '../../src/engine/position'
import { buildPgn } from '../../src/persistence/record'
import { canRedo, canUndo, createGame, playMove, redo, undo } from '../../src/engine/session'
import type { GameState } from '../../src/engine/session'
import type { MoveRecord, PromotionPiece } from '../../src/engine/types'
import { FOOLS_MATE, KNIGHT_SHUFFLE, SCHOLARS_MATE, STALEMATE_LINE, testEnv } from '../unit/helpers'

function mulberry32(seed: number) {
  let a = seed
  return () => {
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

interface Flags {
  fen: string
  check: boolean
  mate: boolean
  stalemate: boolean
  insufficient: boolean
  threefold: boolean
  fifty: boolean
  legal: number
}

const flagsOf = (c: Chess): Flags => ({
  fen: c.fen(),
  check: c.isCheck(),
  mate: c.isCheckmate(),
  stalemate: c.isStalemate(),
  insufficient: c.isInsufficientMaterial(),
  threefold: c.isThreefoldRepetition(),
  fifty: c.isDrawByFiftyMoves(),
  legal: c.moves().length,
})

interface Game {
  moves: MoveRecord[]
  flags: Flags[]
}

const recordOf = (done: { san: string; from: MoveRecord['from']; to: MoveRecord['to']; promotion?: string }): MoveRecord => {
  const rec: MoveRecord = { san: done.san, from: done.from, to: done.to }
  if (done.promotion) rec.promotion = done.promotion as PromotionPiece
  return rec
}

function fromSans(sans: string[]): Game {
  const chess = new Chess()
  const moves: MoveRecord[] = []
  const flags = [flagsOf(chess)]
  for (const san of sans) {
    moves.push(recordOf(chess.move(san)))
    flags.push(flagsOf(chess))
  }
  return { moves, flags }
}

/** Random legal game, biased toward captures, castling, en passant and promotions. */
function randomGame(seed: number, maxPlies: number): Game {
  const rnd = mulberry32(seed)
  const chess = new Chess()
  const moves: MoveRecord[] = []
  const flags = [flagsOf(chess)]
  while (moves.length < maxPlies) {
    const legal = chess.moves({ verbose: true })
    if (legal.length === 0 || chess.isInsufficientMaterial()) break
    const special = legal.filter((m) => m.isCapture() || m.isPromotion() || m.isKingsideCastle() || m.isQueensideCastle() || m.isEnPassant())
    const pool = special.length > 0 && rnd() < 0.55 ? special : legal
    const m = pool[Math.floor(rnd() * pool.length)]
    moves.push(recordOf(chess.move({ from: m.from, to: m.to, promotion: m.promotion })))
    flags.push(flagsOf(chess))
  }
  return { moves, flags }
}

/**
 * All plies of short games. For long ones: the start, every 6th ply, the end, and every
 * "interesting" ply (castling, promotion, en passant square set and the ply after it).
 */
function indicesFor(g: Game): number[] {
  const n = g.moves.length
  if (n <= 60) return Array.from({ length: n + 1 }, (_, i) => i)
  const set = new Set<number>()
  for (let i = 0; i <= 8; i++) set.add(i)
  for (let i = 0; i <= n; i += 6) set.add(i)
  for (let i = Math.max(0, n - 6); i <= n; i++) set.add(i)
  for (let i = 1; i <= n; i++) {
    const m = g.moves[i - 1]
    if (m.promotion || m.san.startsWith('O-O')) set.add(i)
    if (g.flags[i].fen.split(' ')[3] !== '-') {
      set.add(i)
      set.add(Math.min(n, i + 1))
    }
  }
  return [...set].sort((a, b) => a - b)
}

const SEEDS = Array.from({ length: 18 }, (_, i) => 1000 + i * 37)

describe('auditoria: replay do app x chess.js', () => {
  it('posição, xeque, mate, afogamento, material, repetição e 50 lances batem (partidas conhecidas e aleatórias)', () => {
    const known: Game[] = [
      fromSans(SCHOLARS_MATE),
      fromSans(FOOLS_MATE),
      fromSans(STALEMATE_LINE),
      fromSans([...KNIGHT_SHUFFLE, ...KNIGHT_SHUFFLE]), // 3a repetição
    ]
    const games = [...known, ...SEEDS.map((s) => randomGame(s, 110))]
    let checked = 0
    let castles = 0
    let promos = 0
    let epPositions = 0
    for (const [gi, g] of games.entries()) {
      castles += g.moves.filter((m) => m.san.startsWith('O-O')).length
      promos += g.moves.filter((m) => m.promotion).length
      for (const i of indicesFor(g)) {
        const a = analyzeMoves(g.moves, i)
        const f = g.flags[i]
        const where = `partida ${gi}, lance ${i}`
        assert.equal(a.fen, f.fen, `FEN: ${where}`)
        assert.equal(a.inCheck, f.check, `xeque: ${where}`)
        assert.equal(a.legalMoveCount, f.legal, `lances legais: ${where}`)
        assert.equal(a.outcome?.reason === 'checkmate', f.mate, `mate: ${where}`)
        assert.equal(a.outcome?.reason === 'stalemate', f.stalemate, `afogamento: ${where}`)
        if (!f.mate && !f.stalemate) assert.equal(a.outcome?.reason === 'insufficient-material', f.insufficient, `material: ${where}`)
        if (!a.outcome) {
          assert.equal(a.claim.threefold, f.threefold, `repetição tripla: ${where}`)
          assert.equal(a.claim.fiftyMove, f.fifty, `50 lances: ${where}`)
        }
        if (f.fen.split(' ')[3] !== '-') epPositions++
        checked++
      }
    }
    // a amostra tem de ter exercitado as regras especiais, senão o teste não prova nada
    assert.ok(checked > 500, `posições conferidas=${checked}`)
    assert.ok(castles >= 3, `roques=${castles}`)
    assert.ok(promos >= 3, `promoções=${promos}`)
    assert.ok(epPositions >= 3, `posições com en passant=${epPositions}`)
    assert.equal(analyzeMoves(known[0].moves).outcome?.reason, 'checkmate')
    assert.equal(analyzeMoves(known[2].moves).outcome?.reason, 'stalemate')
    assert.equal(analyzeMoves(known[3].moves).claim.threefold, true)
  })

  it('desfazer do app (replay) restaura a mesma posição que o undo() do chess.js, lance a lance', () => {
    let compared = 0
    for (const seed of SEEDS.slice(0, 6)) {
      const { moves, flags } = randomGame(seed, 90)
      const lib = new Chess()
      for (const m of moves) lib.move({ from: m.from, to: m.to, promotion: m.promotion })
      let s: GameState = createGame(testEnv())
      for (const m of moves) {
        const r = playMove(s, { from: m.from, to: m.to, promotion: m.promotion })
        assert.ok(r.ok, `seed ${seed}: ${m.san}`)
        if (r.ok) s = r.state
      }
      const end = s.moves.length
      if (!canUndo(s)) {
        // por decisão de projeto, partida terminada não permite desfazer
        assert.ok(analyzeMoves(s.moves).outcome, 'só bloqueia desfazer em partida terminada')
        continue
      }
      for (let i = end - 1; i >= 0; i--) {
        lib.undo()
        s = undo(s)
        assert.equal(analyzeMoves(s.moves).fen, lib.fen(), `undo seed ${seed} -> lance ${i}`)
        assert.equal(analyzeMoves(s.moves).fen, flags[i].fen)
        compared++
      }
      for (let i = 1; i <= end; i++) {
        s = redo(s)
        assert.equal(analyzeMoves(s.moves).fen, flags[i].fen, `redo seed ${seed} -> lance ${i}`)
      }
      assert.equal(canRedo(s), false)
    }
    assert.ok(compared > 100, `comparações=${compared}`)
  })
})

describe('auditoria: exportação de PGN em partidas aleatórias', () => {
  it('recarregar o PGN no chess.js reproduz os mesmos lances e a mesma posição final', () => {
    for (const seed of SEEDS.slice(0, 12)) {
      const g = randomGame(seed, 100)
      const state: GameState = { ...createGame(testEnv()), moves: g.moves, viewIndex: g.moves.length }
      const pgn = buildPgn(state, { result: '1/2-1/2', reason: 'agreement' })
      const c = new Chess()
      c.loadPgn(pgn)
      assert.deepEqual(c.history(), g.moves.map((m) => m.san), `seed ${seed}`)
      assert.equal(c.fen(), g.flags[g.moves.length].fen, `seed ${seed}`)
      assert.match(pgn, /\[Result "1\/2-1\/2"\]/)
    }
  })
})
