import { after, before, describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { boardState, click, drag, moveTexts, playClicks, settle, start, until } from './helpers.mjs'

let app
before(async () => {
  app = await start()
})
after(async () => {
  await app?.close()
})

const SCHOLARS = 'e2e4 e7e5 d1h5 b8c6 f1c4 g8f6 h5f7'

describe('tabuleiro: jogadas pela interface', () => {
  it('abre sem erros no console, com 32 peças e vez das brancas', async () => {
    const { page, problems, context } = await app.open()
    assert.equal(Object.keys(await boardState(page)).length, 32)
    assert.equal(await page.locator('[data-testid=turn]').innerText(), 'Vez das brancas')
    assert.deepEqual(problems, [])
    await context.close()
  })

  it('clicar numa peça mostra os destinos legais; clicar no destino joga e destaca o lance', async () => {
    const { page, context } = await app.open()
    await click(page, 'e2')
    await until(async () => (await page.locator('cg-board square.move-dest').count()) === 2, 'dois destinos para o peão e2')
    await click(page, 'e4')
    await until(async () => (await moveTexts(page)).join() === 'e4', 'e4 no histórico')
    await settle(page)
    const s = await boardState(page)
    assert.equal(s.e4, 'P')
    assert.equal(s.e2, undefined)
    assert.equal(await page.locator('cg-board square.last-move').count(), 2)
    assert.equal(await page.locator('[data-testid=turn]').innerText(), 'Vez das pretas')
    await context.close()
  })

  it('arrastar e soltar funciona', async () => {
    const { page, context } = await app.open()
    await drag(page, 'g1', 'f3')
    await until(async () => (await moveTexts(page)).join() === 'Nf3', 'Nf3 por arrasto')
    await settle(page)
    assert.equal((await boardState(page)).f3, 'N')
    await context.close()
  })

  it('lance ilegal por arrasto ou clique volta ao lugar e não altera a partida', async () => {
    const { page, context } = await app.open()
    await drag(page, 'e2', 'e5') // peão não anda três casas
    await settle(page, 500)
    assert.equal((await boardState(page)).e2, 'P')
    assert.equal((await boardState(page)).e5, undefined)
    await click(page, 'b1')
    await click(page, 'b3') // cavalo não anda reto
    await settle(page)
    assert.equal((await boardState(page)).b1, 'N')
    await drag(page, 'e7', 'e5') // peça das pretas na vez das brancas
    await settle(page, 500)
    assert.equal((await boardState(page)).e7, 'p')
    assert.deepEqual(await moveTexts(page), [])
    assert.equal(await page.locator('[data-testid=turn]').innerText(), 'Vez das brancas')
    await context.close()
  })

  it('roque pequeno move rei e torre', async () => {
    const { page, context } = await app.open()
    await playClicks(page, 'e2e4 e7e5 g1f3 b8c6 f1c4 f8c5')
    await click(page, 'e1')
    await until(async () => (await page.locator('cg-board square.move-dest').count()) > 0, 'destinos do rei')
    await click(page, 'g1')
    await until(async () => (await moveTexts(page)).at(-1) === 'O-O', 'O-O registrado')
    await settle(page)
    const s = await boardState(page)
    assert.equal(s.g1, 'K')
    assert.equal(s.f1, 'R')
    assert.equal(s.e1, undefined)
    assert.equal(s.h1, undefined)
    await context.close()
  })

  it('en passant remove o peão capturado', async () => {
    const { page, context } = await app.open()
    await playClicks(page, 'e2e4 a7a6 e4e5 d7d5 e5d6')
    await settle(page)
    const s = await boardState(page)
    assert.equal(s.d6, 'P')
    assert.equal(s.d5, undefined)
    assert.equal((await moveTexts(page)).at(-1), 'exd6')
    await context.close()
  })

  it('promoção: o diálogo oferece as 4 peças e a escolhida vai para o tabuleiro', async () => {
    const { page, context } = await app.open()
    await playClicks(page, 'a2a4 b7b5 a4b5 a7a6 b5a6 g8f6 a6a7 h7h6')
    await click(page, 'a7')
    await click(page, 'b8')
    await page.locator('dialog.modal[open] .promo-grid').waitFor()
    assert.deepEqual(await page.locator('.promo-btn').allInnerTexts(), ['Dama', 'Torre', 'Bispo', 'Cavalo'])
    assert.equal((await moveTexts(page)).length, 8) // nada foi jogado antes da escolha
    await page.getByRole('button', { name: 'Cavalo' }).click()
    await until(async () => (await moveTexts(page)).at(-1) === 'axb8=N', 'axb8=N registrado')
    await settle(page)
    assert.equal((await boardState(page)).b8, 'N')
    await context.close()
  })

  it('cancelar a promoção devolve o peão e mantém a vez', async () => {
    const { page, context } = await app.open()
    await playClicks(page, 'a2a4 b7b5 a4b5 a7a6 b5a6 g8f6 a6a7 h7h6')
    await click(page, 'a7')
    await click(page, 'b8')
    await page.getByRole('button', { name: 'Cancelar lance' }).click()
    await settle(page, 700) // deixa a animação de volta terminar
    const s = await boardState(page)
    assert.equal(s.a7, 'P')
    assert.equal(s.b8, 'n')
    assert.equal((await moveTexts(page)).length, 8)
    assert.equal(await page.locator('[data-testid=turn]').innerText(), 'Vez das brancas')
    await context.close()
  })

  it('mate do pastor: resultado, tabuleiro bloqueado e histórico', async () => {
    const { page, context, problems } = await app.open()
    await playClicks(page, SCHOLARS)
    await page.locator('[data-testid=result]').waitFor()
    assert.equal(await page.locator('[data-testid=result]').innerText(), 'Vitória das brancas')
    assert.match(await page.locator('.status-detail').first().innerText(), /Xeque-mate/)
    // nenhum lance é aceito depois do fim
    await click(page, 'a2')
    await click(page, 'a4')
    await settle(page)
    assert.equal((await boardState(page)).a2, 'P')
    assert.equal((await moveTexts(page)).length, 7)
    assert.equal(await page.getByRole('button', { name: 'Desfazer' }).isDisabled(), true)
    assert.equal(await page.getByRole('button', { name: 'Desistir' }).isDisabled(), true)
    // histórico
    await page.getByRole('button', { name: /Partidas/ }).click()
    await page.locator('[data-testid=game-row]').waitFor()
    assert.equal(await page.locator('[data-testid=game-row]').count(), 1)
    assert.match(await page.locator('[data-testid=game-row]').innerText(), /1–0/)
    assert.deepEqual(problems, [])
    await context.close()
  })

  it('reivindicar empate por repetição tripla', async () => {
    const { page, context } = await app.open()
    await playClicks(page, 'g1f3 g8f6 f3g1 f6g8 g1f3 g8f6 f3g1 f6g8')
    await page.getByRole('button', { name: /Reivindicar empate/ }).click()
    await page.locator('[data-testid=result]').waitFor()
    assert.equal(await page.locator('[data-testid=result]').innerText(), 'Empate')
    await context.close()
  })

  it('desistir: escolhe quem desiste e o adversário vence', async () => {
    const { page, context } = await app.open()
    await playClicks(page, 'e2e4 e7e5')
    await page.getByRole('button', { name: 'Desistir' }).click()
    await page.getByRole('button', { name: /Pretas \(pretas\)/ }).click()
    await page.locator('[data-testid=result]').waitFor()
    assert.equal(await page.locator('[data-testid=result]').innerText(), 'Vitória das brancas')
    await context.close()
  })
})

describe('desfazer, refazer, navegação e orientação', () => {
  it('desfazer e refazer mantêm tabuleiro, vez e lista de lances consistentes', async () => {
    const { page, context } = await app.open()
    await playClicks(page, 'e2e4 e7e5')
    await page.getByRole('button', { name: 'Desfazer' }).click()
    await until(async () => (await moveTexts(page)).join() === 'e4', 'um lance depois de desfazer')
    await settle(page)
    let s = await boardState(page)
    assert.equal(s.e7, 'p')
    assert.equal(s.e5, undefined)
    assert.equal(await page.locator('[data-testid=turn]').innerText(), 'Vez das pretas')
    await page.getByRole('button', { name: 'Refazer' }).click()
    await until(async () => (await moveTexts(page)).join() === 'e4,e5', 'e5 de volta')
    await settle(page)
    s = await boardState(page)
    assert.equal(s.e5, 'p')
    assert.equal(await page.getByRole('button', { name: 'Refazer' }).isDisabled(), true)
    await context.close()
  })

  it('setas navegam sem alterar a partida; em posição antiga o tabuleiro não aceita lances', async () => {
    const { page, context } = await app.open()
    await playClicks(page, 'e2e4 e7e5 g1f3')
    await page.keyboard.press('ArrowLeft')
    await page.keyboard.press('ArrowLeft')
    await settle(page)
    let s = await boardState(page)
    assert.equal(s.e4, 'P')
    assert.equal(s.e5, undefined)
    assert.equal(s.f3, undefined)
    assert.equal((await moveTexts(page)).length, 3) // a partida continua com 3 lances
    await page.getByRole('button', { name: 'Voltar ao último lance' }).waitFor()
    await drag(page, 'd2', 'd4')
    await settle(page, 500)
    assert.equal((await boardState(page)).d2, 'P')
    assert.equal((await moveTexts(page)).length, 3)
    await page.keyboard.press('End')
    await settle(page)
    s = await boardState(page)
    assert.equal(s.f3, 'N')
    await page.keyboard.press('Home')
    await settle(page)
    assert.equal((await boardState(page)).e2, 'P')
    await context.close()
  })

  it('clicar num lance da lista mostra aquela posição', async () => {
    const { page, context } = await app.open()
    await playClicks(page, 'd2d4 d7d5 c2c4')
    await page.getByRole('button', { name: 'Lance 2: d5' }).click()
    await settle(page)
    const s = await boardState(page)
    assert.equal(s.d5, 'p')
    assert.equal(s.c4, undefined)
    assert.equal(await page.locator('.move-btn[aria-current=step]').innerText(), 'd5')
    await context.close()
  })

  it('girar inverte a perspectiva e as jogadas continuam corretas', async () => {
    const { page, context } = await app.open()
    await page.getByRole('button', { name: 'Girar' }).click()
    assert.equal(await page.locator('.board-frame .cg-wrap').evaluate((el) => el.classList.contains('orientation-black')), true)
    await settle(page)
    assert.equal((await boardState(page)).e1, 'K')
    await playClicks(page, 'e2e4')
    await settle(page)
    assert.equal((await boardState(page)).e4, 'P')
    await context.close()
  })
})

describe('recuperação e reinício', () => {
  it('a partida em andamento sobrevive a recarregar a página', async () => {
    const { page, context } = await app.open()
    await playClicks(page, 'e2e4 e7e5 g1f3')
    await page.reload()
    await page.waitForSelector('cg-board piece')
    assert.deepEqual(await moveTexts(page), ['e4', 'e5', 'Nf3'])
    await settle(page)
    assert.equal((await boardState(page)).f3, 'N')
    assert.equal(await page.locator('[data-testid=turn]').innerText(), 'Vez das pretas')
    await playClicks(page, 'b8c6') // e continua jogável
    assert.equal((await moveTexts(page)).length, 4)
    await context.close()
  })

  it('partida concluída não duplica no histórico ao recarregar', async () => {
    const { page, context } = await app.open()
    await playClicks(page, SCHOLARS)
    await page.locator('[data-testid=result]').waitFor()
    await page.reload()
    await page.locator('[data-testid=result]').waitFor()
    await page.reload()
    await page.getByRole('button', { name: /Partidas/ }).click()
    await page.locator('[data-testid=game-row]').waitFor()
    assert.equal(await page.locator('[data-testid=game-row]').count(), 1)
    await context.close()
  })

  it('reiniciar pede confirmação quando há progresso; cancelar preserva a partida', async () => {
    const { page, context } = await app.open()
    await playClicks(page, 'e2e4')
    await page.getByRole('button', { name: 'Reiniciar' }).click()
    await page.getByRole('heading', { name: 'Reiniciar a partida?' }).waitFor()
    await page.getByRole('button', { name: 'Cancelar' }).click()
    assert.deepEqual(await moveTexts(page), ['e4'])
    await page.getByRole('button', { name: 'Reiniciar' }).click()
    await page.getByRole('dialog').getByRole('button', { name: 'Reiniciar' }).click()
    await until(async () => (await moveTexts(page)).length === 0, 'partida reiniciada')
    await settle(page)
    assert.equal((await boardState(page)).e2, 'P')
    // sem progresso, reiniciar é imediato
    await page.getByRole('button', { name: 'Reiniciar' }).click()
    assert.equal(await page.locator('dialog[open]').count(), 0)
    await context.close()
  })

  it('nova partida com nomes dos jogadores', async () => {
    const { page, context } = await app.open()
    await page.getByRole('button', { name: 'Nova partida' }).first().click()
    await page.getByLabel('Jogador das brancas').fill('Ana')
    await page.getByLabel('Jogador das pretas').fill('Beto')
    await page.getByRole('button', { name: 'Começar partida' }).click()
    await until(async () => (await page.locator('[data-testid=turn]').innerText()) === 'Vez de Ana', 'vez de Ana')
    assert.match(await page.locator('.player[data-color=b]').innerText(), /Beto/)
    await context.close()
  })

  it('dados corrompidos no armazenamento: abre uma partida nova e avisa', async () => {
    const { page, context } = await app.open()
    await page.evaluate(() => localStorage.setItem('midnight-chess:current', '{"version":1,"session":'))
    await page.reload()
    await page.waitForSelector('cg-board piece')
    assert.deepEqual(await moveTexts(page), [])
    assert.match(await page.locator('.toast').innerText(), /não pôde ser recuperada/)
    await context.close()
  })

  it('armazenamento bloqueado: o jogo funciona e avisa que não será salvo', async () => {
    const context = await app.browser.newContext({ viewport: { width: 1280, height: 800 } })
    await context.addInitScript(() => {
      Object.defineProperty(window, 'localStorage', { get() { throw new Error('blocked') } })
    })
    const page = await context.newPage()
    await page.goto(app.base)
    await page.waitForSelector('cg-board piece')
    assert.match(await page.locator('.banner').innerText(), /bloqueou o armazenamento/)
    await playClicks(page, 'e2e4')
    assert.deepEqual(await moveTexts(page), ['e4'])
    await context.close()
  })
})
