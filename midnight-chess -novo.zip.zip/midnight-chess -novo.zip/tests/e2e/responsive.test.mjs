import { after, before, describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { boardState, moveTexts, playClicks, settle, start } from './helpers.mjs'

let app
before(async () => {
  app = await start()
})
after(async () => {
  await app?.close()
})

const VIEWPORTS = [
  ['celular 360×640', { width: 360, height: 640, isMobile: true, hasTouch: true }],
  ['celular 390×844', { width: 390, height: 844, isMobile: true, hasTouch: true }],
  ['celular deitado 844×390', { width: 844, height: 390, isMobile: true, hasTouch: true }],
  ['tablet 768×1024', { width: 768, height: 1024, isMobile: true, hasTouch: true }],
  ['notebook 1366×768', { width: 1366, height: 768 }],
  ['monitor 1920×1080', { width: 1920, height: 1080 }],
]

describe('layout responsivo', () => {
  for (const [name, vp] of VIEWPORTS) {
    it(`${name}: sem rolagem horizontal e tabuleiro quadrado e visível`, async () => {
      const { page, context, problems } = await app.open({ viewport: { width: vp.width, height: vp.height }, ...vp })
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth)
      assert.equal(overflow, 0, 'não pode haver rolagem horizontal')
      const box = await page.locator('.board-frame').boundingBox()
      assert.ok(Math.abs(box.width - box.height) < 1.5, `tabuleiro quadrado (${box.width}×${box.height})`)
      assert.ok(box.x >= 0 && box.x + box.width <= vp.width + 0.5, 'tabuleiro dentro da largura da tela')
      assert.ok(box.y >= 0 && box.y < vp.height, 'tabuleiro começa dentro da tela')
      assert.ok(box.width >= 200, `tabuleiro grande o bastante (${box.width})`)
      // nenhum controle essencial fica escondido: todos alcançáveis por rolagem
      for (const label of ['Desfazer', 'Refazer', 'Girar', 'Reiniciar', 'Nova partida', 'Empate', 'Desistir']) {
        const btn = page.getByRole('button', { name: label }).first()
        await btn.scrollIntoViewIfNeeded()
        const b = await btn.boundingBox()
        assert.ok(b && b.width > 20 && b.height > 20, `${label} visível`)
        assert.ok(b.x >= 0 && b.x + b.width <= vp.width + 0.5, `${label} dentro da largura`)
      }
      if (vp.isMobile && vp.width < 900 && vp.height > 500) {
        // no fim da rolagem nada fica escondido atrás da barra de abas fixa
        await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight))
        const tabs = await page.locator('.tabs').boundingBox()
        const lowest = await page.evaluate(() => Math.max(...[...document.querySelectorAll('.panel button')].map((b) => b.getBoundingClientRect().bottom)))
        assert.ok(lowest <= tabs.y + 1, `último controle (${lowest}) acima da barra de abas (${tabs.y})`)
      }
      assert.deepEqual(problems, [])
      await context.close()
    })
  }

  it('celular 390×844: desfazer, refazer, girar e setas ficam visíveis sem rolar', async () => {
    const { page, context } = await app.open({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true })
    const tabs = await page.locator('.tabs').boundingBox()
    for (const label of ['Desfazer', 'Refazer', 'Girar', 'Lance anterior', 'Próximo lance']) {
      const b = await page.getByRole('button', { name: label }).first().boundingBox()
      assert.ok(b.y >= 0 && b.y + b.height <= tabs.y, `${label} visível sem rolar (${b.y + b.height} vs ${tabs.y})`)
    }
    await context.close()
  })

  it('celular: alvos de toque com pelo menos 44px e jogada por toque', async () => {
    const { page, context } = await app.open({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 })
    for (const label of ['Primeiro lance', 'Lance anterior', 'Próximo lance', 'Último lance', 'Girar', 'Reiniciar', 'Jogar', 'Partidas']) {
      const b = await page.getByRole('button', { name: new RegExp(label) }).first().boundingBox()
      assert.ok(b.height >= 44 - 0.5 && b.width >= 44 - 0.5, `${label}: ${b.width}×${b.height}`)
    }
    await playClicks(page, 'e2e4 e7e5 g1f3', { touch: true })
    await settle(page)
    assert.equal((await boardState(page)).f3, 'N')
    // histórico compacto: uma faixa horizontal que rola dentro de si mesma
    const moves = await page.locator('.moves').boundingBox()
    assert.ok(moves.height < 80, `faixa de lances compacta (${moves.height})`)
    assert.deepEqual(await moveTexts(page), ['e4', 'e5', 'Nf3'])
    await context.close()
  })

  it('celular: abas na base e a tela de partidas cabe na largura', async () => {
    const { page, context } = await app.open({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true })
    const tabs = await page.locator('.tabs').boundingBox()
    assert.ok(Math.abs(tabs.y + tabs.height - 844) < 2, 'abas coladas na base da tela')
    await playClicks(page, 'f2f3 e7e5 g2g4 d8h4', { touch: true })
    await page.getByRole('button', { name: /Partidas/ }).tap()
    await page.locator('[data-testid=game-row]').waitFor()
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth)
    assert.equal(overflow, 0)
    await page.locator('[data-testid=game-row]').tap()
    await page.locator('[data-testid=replay]').waitFor()
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth), 0)
    await context.close()
  })

  it('computador: tabuleiro e painel lado a lado, aproveitando a tela', async () => {
    const { page, context } = await app.open({ viewport: { width: 1366, height: 768 } })
    const board = await page.locator('.board-frame').boundingBox()
    const panel = await page.locator('.panel').boundingBox()
    assert.ok(panel.x >= board.x + board.width, 'painel ao lado do tabuleiro')
    assert.ok(board.height >= 500, `tabuleiro não é desnecessariamente pequeno (${board.height})`)
    assert.equal(await page.evaluate(() => document.documentElement.scrollHeight <= window.innerHeight + 1), true, 'sem rolagem vertical no notebook')
    await context.close()
  })

  it('respeita movimento reduzido', async () => {
    const { page, context } = await app.open({ reducedMotion: 'reduce' })
    const dur = await page.evaluate(() => {
      const probe = document.createElement('div')
      probe.className = 'toast'
      document.body.appendChild(probe)
      const d = getComputedStyle(probe).animationDuration
      probe.remove()
      return d
    })
    assert.ok(parseFloat(dur) < 0.001 || dur === '1e-05s', `duração da animação: ${dur}`)
    await context.close()
  })
})
