import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { Chess } from '../../src/engine/chessLib'
import { CATEGORY_LABEL, PRESETS, allowsManualPause, categoryOf, controlFrom, createClock, formatClock, formatControl, timeLeft } from '../../src/engine/clock'
import { hasInsufficientMaterial } from '../../src/engine/position'
import {
  agreeDraw, applyTimeout, canLeaveGame, canPlay, canRedo, canUndo, claimDraw, createGame, flaggedSide, isFinished, outcomeOf,
  pauseClock, playMove, redo, resign, restoreClock, resumeClock, timeLeftOf, undo,
} from '../../src/engine/session'
import type { GameState } from '../../src/engine/session'
import { BLITZ_3_2, BULLET_1_0, FOOLS_MATE, KNIGHT_SHUFFLE, LONE_KING_LINE, RAPID_10_0, clockEnv, playAt } from './helpers'

const T0 = Date.UTC(2026, 9, 18, 12, 0, 0)
const timedGame = (control = BLITZ_3_2) => createGame(clockEnv().env, {}, 'w', control)

/** Plays the given SANs one second apart, starting at `t`, and returns the state and the next instant. */
function playSeries(state: GameState, t: number, sans: string[], stepMs = 1000) {
  let s = state
  let now = t
  for (const san of sans) {
    s = playAt(s, now, san)
    now += stepMs
  }
  return { s, now }
}

describe('modos e controles de tempo', () => {
  it('as predefinições pertencem à categoria que dizem pertencer', () => {
    assert.equal(PRESETS.length, 9)
    for (const p of PRESETS) {
      const c = controlFrom(p.baseMin, p.incrementSec)
      assert.ok(c, `${p.baseMin}+${p.incrementSec}`)
      assert.equal(categoryOf(c), p.category, `${p.baseMin}+${p.incrementSec} deveria ser ${CATEGORY_LABEL[p.category]}`)
    }
  })

  it('fronteiras de classificação: base + 40 acréscimos (<180 bullet, <480 blitz, <1500 rápido)', () => {
    const k = (baseMin: number, inc: number) => categoryOf(controlFrom(baseMin, inc)!)
    assert.equal(k(2, 1), 'bullet') // 160
    assert.equal(k(3, 0), 'blitz') // 180
    assert.equal(k(7, 0), 'blitz') // 420
    assert.equal(k(8, 0), 'rapid') // 480
    assert.equal(k(15, 10), 'rapid') // 1300
    assert.equal(k(25, 0), 'classical') // 1500
    assert.equal(k(180, 60), 'classical')
  })

  it('só Rápido e Clássico têm pausa manual', () => {
    assert.deepEqual(
      [BULLET_1_0, BLITZ_3_2, RAPID_10_0, { baseMs: 1_800_000, incrementMs: 0 }].map(allowsManualPause),
      [false, false, true, true],
    )
  })

  it('controles personalizados fora dos limites são recusados', () => {
    assert.equal(controlFrom(0, 0), null)
    assert.equal(controlFrom(181, 0), null)
    assert.equal(controlFrom(5, -1), null)
    assert.equal(controlFrom(5, 61), null)
    assert.equal(controlFrom(2.5, 0), null)
    assert.equal(controlFrom(Number.NaN, 0), null)
    assert.deepEqual(controlFrom(3, 2), BLITZ_3_2)
    assert.equal(formatControl(BLITZ_3_2), '3+2')
    assert.equal(formatControl(RAPID_10_0), '10+0')
  })

  it('formatação do relógio', () => {
    assert.equal(formatClock(185_000), '3:05')
    assert.equal(formatClock(600_000), '10:00')
    assert.equal(formatClock(3_725_000), '1:02:05')
    assert.equal(formatClock(10_000), '0:10')
    assert.equal(formatClock(9_999), '10.0')
    assert.equal(formatClock(9_400), '9.4')
    assert.equal(formatClock(9_401), '9.5')
    assert.equal(formatClock(1), '0.1')
    assert.equal(formatClock(0), '0.0')
    assert.equal(formatClock(-50), '0.0')
  })
})

describe('contagem do tempo (Fischer 3+2)', () => {
  it('antes do primeiro lance nada corre; o primeiro lance das brancas é grátis e liga o relógio das pretas', () => {
    const s0 = timedGame()
    assert.deepEqual(s0.clock, { control: BLITZ_3_2, remaining: { w: 180_000, b: 180_000 }, since: null, paused: null })
    assert.equal(timeLeftOf(s0, 'w', T0 + 3_600_000), 180_000) // uma hora depois, nada mudou
    const s1 = playAt(s0, T0 + 50_000, 'e4') // brancas "pensaram" 50 s antes do 1º lance
    assert.deepEqual(s1.clock?.remaining, { w: 180_000, b: 180_000 }) // sem desconto e sem acréscimo
    assert.equal(s1.clock?.since, T0 + 50_000)
  })

  it('a partir do segundo lance desconta o tempo gasto e soma o acréscimo a quem jogou', () => {
    let { s, now } = playSeries(timedGame(), T0, ['e4'], 0)
    s = playAt(s, now + 7_000, 'e5') // pretas gastaram 7 s: 180 - 7 + 2
    assert.equal(s.clock?.remaining.b, 175_000)
    assert.equal(s.clock?.since, now + 7_000)
    s = playAt(s, now + 7_000 + 20_000, 'Nf3') // brancas gastaram 20 s: 180 - 20 + 2 (o 1º lance foi grátis)
    assert.equal(s.clock?.remaining.w, 162_000)
    assert.equal(s.clock?.remaining.b, 175_000)
  })

  it('o relógio de quem está na vez corre; o do outro fica parado', () => {
    const { s, now } = playSeries(timedGame(), T0, ['e4'], 0)
    assert.equal(timeLeftOf(s, 'b', now + 30_000), 150_000)
    assert.equal(timeLeftOf(s, 'w', now + 30_000), 180_000)
  })

  it('relógio sem acréscimo (10+0) não soma nada', () => {
    let { s, now } = playSeries(timedGame(RAPID_10_0), T0, ['d4'], 0)
    s = playAt(s, now + 5_000, 'd5')
    assert.equal(s.clock?.remaining.b, 595_000)
  })

  it('instante anterior ao início (relógio do sistema andou para trás) não gera tempo negativo nem bônus', () => {
    const { s, now } = playSeries(timedGame(), T0, ['e4'], 0)
    assert.equal(timeLeftOf(s, 'b', now - 5_000), 180_000)
    const s2 = playAt(s, now - 5_000, 'e5')
    assert.equal(s2.clock?.remaining.b, 182_000) // nada descontado, só o acréscimo
  })

  it('partida com relógio exige o instante em playMove', () => {
    assert.throws(() => playMove(timedGame(), { from: 'e2', to: 'e4' }), /instante atual/)
  })
})

describe('bandeira (tempo esgotado)', () => {
  const afterE4 = () => playSeries(timedGame(), T0, ['e4'], 0)

  it('detecta exatamente quando o tempo chega a zero', () => {
    const { s, now } = afterE4()
    assert.equal(flaggedSide(s, now + 179_999), null)
    assert.equal(flaggedSide(s, now + 180_000), 'b')
    assert.equal(flaggedSide(s, now + 999_999), 'b')
  })

  it('um lance no instante da queda é recusado e não altera a partida', () => {
    const { s, now } = afterE4()
    const r = playMove(s, { from: 'e7', to: 'e5' }, now + 180_000)
    assert.deepEqual(r, { ok: false, error: 'time-over' })
    assert.equal(s.moves.length, 1)
    assert.equal(playMove(s, { from: 'e7', to: 'e5' }, now + 179_999).ok, true) // 1 ms antes ainda vale
  })

  it('quem fica sem tempo perde; o relógio para e a partida termina', () => {
    const { s, now } = afterE4()
    const done = applyTimeout(s, now + 200_000)
    assert.deepEqual(outcomeOf(done), { result: '1-0', reason: 'timeout', winner: 'w', flagged: 'b' })
    assert.equal(done.clock?.since, null)
    assert.equal(done.clock?.remaining.b, 0)
    assert.equal(done.clock?.remaining.w, 180_000)
    assert.equal(isFinished(done), true)
    assert.deepEqual(playMove(done, { from: 'e7', to: 'e5' }, now + 201_000), { ok: false, error: 'game-over' })
    assert.equal(applyTimeout(done, now + 300_000), done) // não aplica duas vezes
  })

  it('as brancas também podem perder por tempo', () => {
    let { s, now } = playSeries(timedGame(BULLET_1_0), T0, ['e4', 'e5'], 0)
    s = applyTimeout(s, now + 60_000)
    assert.deepEqual(outcomeOf(s), { result: '0-1', reason: 'timeout', winner: 'b', flagged: 'w' })
    void now
  })

  it('FIDE 6.9: se o adversário não tem material para dar mate, é empate (não derrota)', () => {
    let { s, now } = playSeries(timedGame(RAPID_10_0), T0, LONE_KING_LINE, 0)
    assert.equal(outcomeOf(s), null) // a partida segue em andamento
    assert.equal(s.moves.length, LONE_KING_LINE.length)
    s = applyTimeout(s, now + 700_000) // pretas (na vez) estouram; brancas só têm o rei
    assert.deepEqual(outcomeOf(s), { result: '1/2-1/2', reason: 'timeout-insufficient', flagged: 'b' })
  })

  it('sem relógio nada disso existe', () => {
    const s = createGame(clockEnv().env)
    assert.equal(flaggedSide(s, T0 + 1e12), null)
    assert.equal(applyTimeout(s, T0 + 1e12), s)
    assert.equal(timeLeftOf(s, 'w', T0), null)
  })
})

describe('pausa', () => {
  const blitzAfterE4 = () => playSeries(timedGame(BLITZ_3_2), T0, ['e4'], 0)
  const rapidAfterE4 = () => playSeries(timedGame(RAPID_10_0), T0, ['e4'], 0)

  it('pausa manual não existe em Bullet e Blitz', () => {
    const { s, now } = blitzAfterE4()
    assert.equal(pauseClock(s, now + 5_000, 'manual'), s)
    const bullet = playSeries(timedGame(BULLET_1_0), T0, ['e4'], 0)
    assert.equal(pauseClock(bullet.s, bullet.now + 5_000, 'manual'), bullet.s)
  })

  it('pausa manual em Rápido: cobra o tempo até aquele instante, para os dois relógios e trava os lances', () => {
    const { s, now } = rapidAfterE4()
    const p = pauseClock(s, now + 5_000, 'manual')
    assert.equal(p.clock?.paused, 'manual')
    assert.equal(p.clock?.since, null)
    assert.equal(p.clock?.remaining.b, 595_000)
    assert.equal(p.clock?.remaining.w, 600_000)
    assert.equal(canPlay(p), false)
    assert.deepEqual(playMove(p, { from: 'e7', to: 'e5' }, now + 6_000), { ok: false, error: 'paused' })
    assert.equal(timeLeftOf(p, 'b', now + 3_600_000), 595_000) // uma hora parada: nada corre
    assert.equal(flaggedSide(p, now + 3_600_000), null)
  })

  it('retomar religa o relógio sem cobrar o tempo parado', () => {
    const { s, now } = rapidAfterE4()
    const p = pauseClock(s, now + 5_000, 'manual')
    const r = resumeClock(p, now + 5_000 + 600_000) // 10 minutos de pausa
    assert.equal(r.clock?.paused, null)
    assert.equal(r.clock?.since, now + 5_000 + 600_000)
    assert.equal(timeLeftOf(r, 'b', now + 5_000 + 600_000 + 10_000), 585_000)
    assert.equal(canPlay(r), true)
    assert.equal(playMove(r, { from: 'e7', to: 'e5' }, now + 5_000 + 600_000 + 10_000).ok, true)
  })

  it('pausa automática vale em qualquer modo (app saiu de foco)', () => {
    const { s, now } = blitzAfterE4()
    const p = pauseClock(s, now + 12_000, 'auto')
    assert.equal(p.clock?.paused, 'auto')
    assert.equal(p.clock?.remaining.b, 168_000)
    assert.equal(canPlay(p), false)
  })

  it('não há o que pausar antes do primeiro lance, depois do fim, nem duas vezes', () => {
    const fresh = timedGame(RAPID_10_0)
    assert.equal(pauseClock(fresh, T0, 'manual'), fresh)
    assert.equal(pauseClock(fresh, T0, 'auto'), fresh)
    const { s, now } = rapidAfterE4()
    const p = pauseClock(s, now + 1_000, 'manual')
    assert.equal(pauseClock(p, now + 2_000, 'auto'), p)
    const over = resign(s, 'b', now + 1_000)
    assert.equal(pauseClock(over, now + 2_000, 'auto'), over)
    assert.equal(resumeClock(over, now + 3_000), over)
  })

  it('partida sem relógio ignora pausa e retomada', () => {
    const s = createGame(clockEnv().env)
    assert.equal(pauseClock(s, T0, 'auto'), s)
    assert.equal(resumeClock(s, T0), s)
  })

  it('restaurar do armazenamento volta pausada e não cobra o tempo desde o último evento', () => {
    const { s, now } = blitzAfterE4()
    const back = restoreClock(s) // `s` tinha o relógio das pretas correndo
    assert.equal(back.clock?.paused, 'restore')
    assert.equal(back.clock?.since, null)
    assert.deepEqual(back.clock?.remaining, s.clock?.remaining)
    assert.equal(timeLeftOf(back, 'b', now + 86_400_000), 180_000)
    // idempotente, e sem efeito onde não há relógio correndo
    assert.equal(restoreClock(back), back)
    const fresh = timedGame()
    assert.equal(restoreClock(fresh), fresh)
    assert.equal(restoreClock(createGame(clockEnv().env)).clock, null)
    const over = resign(s, 'b', now)
    assert.equal(restoreClock(over), over)
  })
})

describe('fim da partida para o relógio', () => {
  it('xeque-mate, desistência, acordo e reivindicação param o relógio e cobram o tempo até ali', () => {
    const mate = playSeries(timedGame(), T0, FOOLS_MATE, 3_000)
    assert.equal(outcomeOf(mate.s)?.reason, 'checkmate')
    assert.equal(mate.s.clock?.since, null)

    let { s, now } = playSeries(timedGame(), T0, ['e4', 'e5'], 0)
    const r = resign(s, 'w', now + 9_000)
    assert.equal(r.clock?.since, null)
    assert.equal(r.clock?.remaining.w, 171_000) // brancas na vez, 9 s cobrados
    assert.equal(agreeDraw(s, now + 4_000).clock?.remaining.w, 176_000)

    ;({ s, now } = playSeries(timedGame(), T0, [...KNIGHT_SHUFFLE, ...KNIGHT_SHUFFLE], 0))
    const c = claimDraw(s, now + 2_000)
    assert.equal(outcomeOf(c)?.reason, 'threefold-claimed')
    assert.equal(c.clock?.since, null)
    assert.throws(() => resign(playSeries(timedGame(), T0, ['e4'], 0).s, 'b'), /instante atual/)
  })
})

describe('desfazer, refazer e recomeçar em partidas com relógio', () => {
  it('nunca se desfaz nem se refaz com relógio', () => {
    const { s } = playSeries(timedGame(), T0, ['e4', 'e5'], 0)
    assert.equal(canUndo(s), false)
    assert.equal(canRedo(s), false)
    assert.equal(undo(s), s)
    assert.equal(redo(s), s)
  })

  it('sem relógio, continua desfazendo normalmente', () => {
    const r = playMove(createGame(clockEnv().env), { from: 'e2', to: 'e4' })
    assert.ok(r.ok)
    if (r.ok) {
      assert.equal(canUndo(r.state), true)
      assert.equal(canLeaveGame(r.state), true)
      assert.equal(undo(r.state).moves.length, 0)
    }
  })

  it('não se sai de uma partida com relógio em andamento; antes do 1º lance e depois do fim, sim', () => {
    const fresh = timedGame()
    assert.equal(canLeaveGame(fresh), true)
    const { s, now } = playSeries(timedGame(), T0, ['e4'], 0)
    assert.equal(canLeaveGame(s), false)
    assert.equal(canLeaveGame(resign(s, 'b', now)), true)
    assert.equal(canLeaveGame(pauseClock(playSeries(timedGame(RAPID_10_0), T0, ['e4'], 0).s, T0 + 1, 'manual')), false) // pausar não libera
  })
})

describe('material insuficiente para dar mate (por lado)', () => {
  const side = (fen: string, color: 'w' | 'b') => hasInsufficientMaterial(new Chess(fen), color)
  const table: Array<[string, string, boolean, boolean]> = [
    // nome, FEN, brancas não podem dar mate, pretas não podem dar mate
    ['K x K', '8/8/8/4k3/8/8/4K3/8 w - - 0 1', true, true],
    ['K+C x K', '8/8/8/4k3/8/8/4KN2/8 w - - 0 1', true, true],
    ['K+C x K+P: o peão poderia bloquear o próprio rei', '8/8/8/4k3/8/p7/4KN2/8 w - - 0 1', false, false],
    ['K+C x K+D: só damas não permitem auto-mate', '8/8/8/4k3/8/q7/4KN2/8 w - - 0 1', true, false],
    ['K+C+C x K', '8/8/8/4k3/8/8/4KNN1/8 w - - 0 1', false, true],
    ['K+B x K', '8/8/8/4k3/8/8/4KB2/8 w - - 0 1', true, true],
    ['K+B x K+B, mesma cor', '8/8/4b3/4k3/8/8/4K3/5B2 w - - 0 1', true, true],
    ['K+B x K+B, cores opostas', '8/8/3b4/4k3/8/8/4K3/5B2 w - - 0 1', false, false],
    ['K+B x K+C', '8/8/4n3/4k3/8/8/4KB2/8 w - - 0 1', false, false],
    ['K+B+B, cores opostas x K', '8/8/8/4k3/8/8/4K3/2BB4 w - - 0 1', false, true],
    ['K+T x K', '8/8/8/4k3/8/8/4KR2/8 w - - 0 1', false, true],
    ['K+D x K', '8/8/8/4k3/8/8/4KQ2/8 w - - 0 1', false, true],
    ['K+P x K', '8/8/8/4k3/8/8/4KP2/8 w - - 0 1', false, true],
  ]
  for (const [name, fen, whiteCannot, blackCannot] of table) {
    it(name, () => {
      assert.equal(side(fen, 'w'), whiteCannot, 'brancas')
      assert.equal(side(fen, 'b'), blackCannot, 'pretas')
    })
  }

  it('a posição real da sequência de teste: brancas só com o rei, pretas com material', () => {
    const c = new Chess()
    for (const san of LONE_KING_LINE) c.move(san)
    assert.equal(hasInsufficientMaterial(c, 'w'), true)
    assert.equal(hasInsufficientMaterial(c, 'b'), false)
    assert.equal(timeLeft(createClock(BLITZ_3_2), 'w', 'w', T0), 180_000)
  })
})
