import { Chess } from '../../src/engine/chessLib'
import { createGame, playMove } from '../../src/engine/session'
import type { GameEnv, GameState } from '../../src/engine/session'
import type { TimeControl } from '../../src/engine/clock'
import { KEYS, Persistence } from '../../src/persistence/storage'
import type { StorageLike } from '../../src/persistence/storage'
import { GameStore } from '../../src/store/gameStore'

export function testEnv(start = Date.UTC(2026, 9, 16, 12, 0, 0)): GameEnv {
  let n = 0
  let t = start
  return {
    now: () => new Date((t += 60_000)),
    newId: () => `game-${++n}`,
  }
}

export class MemoryStorage implements StorageLike {
  readonly data = new Map<string, string>()
  failWrites = false
  getItem(k: string) {
    return this.data.get(k) ?? null
  }
  setItem(k: string, v: string) {
    if (this.failWrites) throw new Error('QuotaExceededError')
    this.data.set(k, v)
  }
  removeItem(k: string) {
    this.data.delete(k)
  }
}

export { KEYS }

/** Plays SAN moves through the real session API (from/to resolved with chess.js). */
export function play(state: GameState, ...sans: string[]): GameState {
  let s = state
  for (const san of sans) {
    const chess = new Chess()
    for (const m of s.moves) chess.move({ from: m.from, to: m.to, promotion: m.promotion })
    const mv = chess.move(san)
    const r = playMove(s, { from: mv.from, to: mv.to, promotion: mv.promotion as 'q' | 'r' | 'b' | 'n' | undefined })
    if (!r.ok) throw new Error(`play(${san}) rejected: ${r.error}`)
    s = r.state
  }
  return s
}

export const newState = (env = testEnv()) => createGame(env)

export function newStore(storage: StorageLike | null = new MemoryStorage(), env = testEnv()) {
  const persistence = new Persistence(storage, env.now)
  return { store: new GameStore(persistence, env), persistence, env, storage }
}

export const SCHOLARS_MATE = ['e4', 'e5', 'Qh5', 'Nc6', 'Bc4', 'Nf6', 'Qxf7#']
export const FOOLS_MATE = ['f3', 'e5', 'g4', 'Qh4#']
export const STALEMATE_LINE = [
  'e3', 'a5', 'Qh5', 'Ra6', 'Qxa5', 'h5', 'h4', 'Rah6', 'Qxc7', 'f6',
  'Qxd7+', 'Kf7', 'Qxb7', 'Qd3', 'Qxb8', 'Qh7', 'Qxc8', 'Kg6', 'Qe6',
]
export const KNIGHT_SHUFFLE = ['Nf3', 'Nf6', 'Ng1', 'Ng8']

/** Environment whose time only moves when the test says so. */
export function clockEnv(start = Date.UTC(2026, 9, 18, 12, 0, 0)) {
  let t = start
  let n = 0
  const env: GameEnv = { now: () => new Date(t), newId: () => `clk-${++n}` }
  return {
    env,
    advance(ms: number) {
      t += ms
    },
    get time() {
      return t
    },
  }
}

export const BULLET_1_0: TimeControl = { baseMs: 60_000, incrementMs: 0 }
export const BLITZ_3_2: TimeControl = { baseMs: 180_000, incrementMs: 2_000 }
export const RAPID_10_0: TimeControl = { baseMs: 600_000, incrementMs: 0 }

/** Plays ONE SAN move at an explicit instant (needed in timed games). */
export function playAt(state: GameState, now: number, san: string): GameState {
  const chess = new Chess()
  for (const m of state.moves) chess.move({ from: m.from, to: m.to, promotion: m.promotion })
  const mv = chess.move(san)
  const r = playMove(state, { from: mv.from, to: mv.to, promotion: mv.promotion as 'q' | 'r' | 'b' | 'n' | undefined }, now)
  if (!r.ok) throw new Error(`playAt(${san}) rejected: ${r.error}`)
  return r.state
}

/**
 * Real legal game (found by a seeded search) that ends with White holding only the king and
 * Black, with plenty of material, to move: if Black then flags, White cannot mate.
 */
export const LONE_KING_LINE = [
  'd3', 'a5', 'Qd2', 'e5', 'Qe3', 'f5', 'Na3', 'Bxa3', 'c4', 'Bxb2', 'Nh3', 'Bxa1', 'Qc5', 'Qf6', 'Kd2', 'h5', 'Rg1', 'Rh7',
  'Qa3', 'Nc6', 'Qb4', 'axb4', 'c5', 'Ra5', 'e3', 'Rxa2+', 'Bb2', 'Ra3', 'Rh1', 'Bxb2', 'g4', 'hxg4', 'Be2', 'gxh3', 'Rb1',
  'Na5', 'c6', 'Rh8', 'Rf1', 'Rxd3+', 'Ke1', 'Nxc6', 'Rh1', 'Rxe3', 'Kf1', 'Rxe2', 'f3', 'Rxh2', 'Kg1', 'Rxh1+', 'Kf2', 'Nh6',
  'f4', 'exf4', 'Kf3',
]
