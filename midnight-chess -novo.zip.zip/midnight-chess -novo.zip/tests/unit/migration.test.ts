import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { migrate, SCHEMA_VERSION } from '../../src/persistence/schema'
import { KEYS, Persistence } from '../../src/persistence/storage'
import { FOOLS_MATE, MemoryStorage, clockEnv, newStore } from './helpers'
import { Chess } from '../../src/engine/chessLib'

/** Files written by the v1 code (generated before the 2.0 changes; see tests/fixtures/v1). */
const fixture = (name: string) => readFileSync(new URL(`../fixtures/v1/${name}`, import.meta.url), 'utf8')
const V1_CURRENT = fixture('current.json')
const V1_HISTORY = fixture('history.json')

describe('migração v1 -> v2: partida em andamento', () => {
  it('lê o arquivo antigo sem perder nada e guarda uma cópia intacta', () => {
    const storage = new MemoryStorage()
    storage.setItem(KEYS.current, V1_CURRENT)
    const r = new Persistence(storage).loadCurrent()
    assert.equal(r.status, 'ok')
    if (r.status !== 'ok') return
    const raw = JSON.parse(V1_CURRENT)
    assert.equal(r.state.id, raw.session.id)
    assert.equal(r.state.startedAt, raw.session.startedAt)
    assert.deepEqual(r.state.players, { w: 'Gui', b: 'Hana' })
    assert.deepEqual(r.state.moves, raw.session.moves)
    assert.deepEqual(r.state.redo, raw.session.redo)
    assert.equal(r.state.moves.length, 6)
    assert.equal(r.state.redo.length, 2)
    assert.equal(r.state.orientation, 'b')
    assert.equal(r.state.clock, null) // antes não existia relógio: partida sem relógio
    assert.equal(r.archived, false)
    assert.equal(storage.getItem(`${KEYS.current}:backup-v1`), V1_CURRENT)
  })

  it('a cópia de segurança é feita uma vez e não é sobrescrita nas leituras seguintes', () => {
    const storage = new MemoryStorage()
    storage.setItem(KEYS.current, V1_CURRENT)
    const p = new Persistence(storage)
    p.loadCurrent()
    storage.setItem(`${KEYS.current}:backup-v1`, 'copia-original')
    p.loadCurrent()
    assert.equal(storage.getItem(`${KEYS.current}:backup-v1`), 'copia-original')
  })

  it('o app abre com a partida antiga, permite refazer e passa a gravar na v2', () => {
    const c = clockEnv()
    const storage = new MemoryStorage()
    storage.setItem(KEYS.current, V1_CURRENT)
    const { store } = newStore(storage, c.env)
    let s = store.getSnapshot()
    assert.equal(s.game.moves.length, 6)
    assert.equal(s.canRedo, true)
    assert.equal(s.canUndo, true)
    store.redo()
    s = store.getSnapshot()
    assert.equal(s.game.moves.length, 7)
    const saved = JSON.parse(storage.getItem(KEYS.current) ?? '{}')
    assert.equal(saved.version, SCHEMA_VERSION)
    assert.equal(saved.session.clock, null)
    assert.equal(saved.session.moves.length, 7)
    assert.equal(newStore(storage, c.env).store.getSnapshot().game.moves.length, 7) // e relê o que gravou
  })
})

describe('migração v1 -> v2: histórico', () => {
  it('as três partidas antigas aparecem com os mesmos dados e os campos novos padrão', () => {
    const storage = new MemoryStorage()
    storage.setItem(KEYS.history, V1_HISTORY)
    const { games, warnings } = new Persistence(storage).loadHistory()
    assert.deepEqual(warnings, [])
    const raw = JSON.parse(V1_HISTORY).games as Array<Record<string, unknown>>
    assert.equal(games.length, 3)
    for (const old of raw) {
      const migrated = games.find((g) => g.id === old.id)
      assert.ok(migrated, String(old.id))
      for (const [k, v] of Object.entries(old)) assert.deepEqual((migrated as unknown as Record<string, unknown>)[k], v, `${old.id}.${k}`)
      assert.equal(migrated.source, 'played')
      assert.equal(migrated.timeControl, null)
    }
    assert.equal(storage.getItem(`${KEYS.history}:backup-v1`), V1_HISTORY)
  })

  it('estatísticas e lista funcionam com dados antigos; uma partida nova é somada sem tocar nas antigas', () => {
    const c = clockEnv()
    const storage = new MemoryStorage()
    storage.setItem(KEYS.history, V1_HISTORY)
    const { store } = newStore(storage, c.env)
    let snap = store.getSnapshot()
    assert.deepEqual(snap.stats, { total: 3, whiteWins: 2, blackWins: 0, draws: 1, averageMoves: snap.stats.averageMoves })
    const before = JSON.parse(V1_HISTORY).games.map((g: { id: string }) => g.id).sort()

    store.newGame({ w: 'Nova', b: 'Partida' })
    for (const san of FOOLS_MATE) {
      const chess = new Chess()
      for (const m of store.getState().moves) chess.move({ from: m.from, to: m.to, promotion: m.promotion })
      const mv = chess.move(san)
      store.move(mv.from, mv.to)
    }
    snap = store.getSnapshot()
    assert.equal(snap.history.length, 4)
    const ids = snap.history.map((g) => g.id)
    for (const id of before) assert.ok(ids.includes(id), `partida antiga ${id} preservada`)
    const onDisk = JSON.parse(storage.getItem(KEYS.history) ?? '{}')
    assert.equal(onDisk.version, SCHEMA_VERSION)
    assert.equal(onDisk.games.length, 4)
    assert.equal(newStore(storage, c.env).store.getSnapshot().history.length, 4)
  })
})

describe('migrate()', () => {
  it('só acrescenta campos e é idempotente', () => {
    const v1 = JSON.parse(V1_CURRENT)
    const m1 = migrate(v1)
    assert.ok(m1.ok)
    if (!m1.ok) return
    assert.equal(m1.value.version, 2)
    assert.deepEqual({ ...(m1.value.session as object), clock: undefined }, { ...v1.session, clock: undefined })
    const m2 = migrate(m1.value)
    assert.ok(m2.ok)
    if (m2.ok) assert.equal(m2.value, m1.value)
    assert.equal(JSON.stringify(v1), V1_CURRENT) // a entrada não foi alterada
  })

  it('recusa versão ausente, inválida ou mais nova que a suportada', () => {
    assert.equal(migrate({}).ok, false)
    assert.equal(migrate({ version: 0 }).ok, false)
    assert.equal(migrate({ version: 1.5 }).ok, false)
    assert.equal(migrate({ version: 'x' }).ok, false)
    const future = migrate({ version: SCHEMA_VERSION + 1 })
    assert.equal(future.ok, false)
    if (!future.ok) assert.match(future.error, /mais nova/)
  })
})
