/**
 * Auditoria das regras (Fase 1): cenários determinísticos de restauração de estado e de
 * repetição conforme as regras oficiais. Os cruzamentos aleatórios com o chess.js ficam
 * em tests/audit (mais lentos).
 */
import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { Chess } from '../../src/engine/chessLib'
import { analyzeChess, analyzeMoves, replay } from '../../src/engine/position'
import { redo, undo } from '../../src/engine/session'
import type { GameState } from '../../src/engine/session'
import type { MoveRecord } from '../../src/engine/types'
import { newState, play } from './helpers'

const fields = (fen: string) => {
  const [board, turn, castling, ep, half, full] = fen.split(' ')
  return { board, turn, castling, ep, half: Number(half), full: Number(full) }
}

describe('auditoria: desfazer/refazer restauram todo o estado da posição', () => {
  it('direitos de roque voltam ao desfazer o lance que os perdeu', () => {
    let s = play(newState(), 'e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5')
    assert.equal(fields(analyzeMoves(s.moves).fen).castling, 'KQkq')
    s = play(s, 'Ke2')
    assert.equal(fields(analyzeMoves(s.moves).fen).castling, 'kq') // perdeu K e Q das brancas
    assert.equal(fields(analyzeMoves(undo(s).moves).fen).castling, 'KQkq') // voltou
    s = play(undo(s), 'O-O')
    assert.equal(fields(analyzeMoves(s.moves).fen).castling, 'kq')
    const back = undo(s)
    assert.equal(fields(analyzeMoves(back.moves).fen).castling, 'KQkq')
    assert.equal(fields(analyzeMoves(redo(back).moves).fen).castling, 'kq')
  })

  it('torre que se moveu tira só o direito do seu lado, e desfazer o devolve', () => {
    let s = play(newState(), 'a4', 'a5', 'Ra3')
    assert.equal(fields(analyzeMoves(s.moves).fen).castling, 'Kkq')
    s = undo(s)
    assert.equal(fields(analyzeMoves(s.moves).fen).castling, 'KQkq')
  })

  it('casa de en passant aparece só quando a captura é possível e volta ao refazer', () => {
    let s = play(newState(), 'e4', 'a6', 'e5')
    assert.equal(fields(analyzeMoves(s.moves).fen).ep, '-')
    s = play(s, 'd5')
    assert.equal(fields(analyzeMoves(s.moves).fen).ep, 'd6')
    assert.equal(fields(analyzeMoves(undo(s).moves).fen).ep, '-')
    assert.equal(fields(analyzeMoves(redo(undo(s)).moves).fen).ep, 'd6')
    // sem peão adversário ao lado, a casa não é registrada
    const t = play(newState(), 'e4')
    assert.equal(fields(analyzeMoves(t.moves).fen).ep, '-')
  })

  it('contador de meio-lances e número do lance voltam ao desfazer captura e avanço de peão', () => {
    let s = play(newState(), 'Nf3', 'Nf6', 'Nc3', 'Nc6') // 4 meio-lances sem captura nem peão
    assert.deepEqual([fields(analyzeMoves(s.moves).fen).half, fields(analyzeMoves(s.moves).fen).full], [4, 3])
    s = play(s, 'e4') // peão zera o contador
    assert.equal(fields(analyzeMoves(s.moves).fen).half, 0)
    assert.equal(fields(analyzeMoves(undo(s).moves).fen).half, 4)
    s = play(s, 'Nxe4') // captura zera de novo; número do lance avança após as pretas
    assert.deepEqual([fields(analyzeMoves(s.moves).fen).half, fields(analyzeMoves(s.moves).fen).full], [0, 4])
    const back = undo(s)
    assert.deepEqual([fields(analyzeMoves(back.moves).fen).half, fields(analyzeMoves(back.moves).fen).full], [0, 3])
    assert.equal(fields(analyzeMoves(undo(back).moves).fen).half, 4)
  })

  it('xeque e possibilidade de repetição acompanham o desfazer', () => {
    let s = play(newState(), 'e4', 'f5', 'Qh5+')
    assert.equal(analyzeMoves(s.moves).inCheck, true)
    s = undo(s)
    assert.equal(analyzeMoves(s.moves).inCheck, false)
    assert.equal(analyzeMoves(redo(s).moves).inCheck, true)

    const shuffle = ['Nf3', 'Nf6', 'Ng1', 'Ng8']
    const rep = play(newState(), ...shuffle, ...shuffle)
    assert.equal(analyzeMoves(rep.moves).claim.threefold, true)
    assert.equal(analyzeMoves(undo(rep).moves).claim.threefold, false)
    assert.equal(analyzeMoves(redo(undo(rep)).moves).claim.threefold, true)
  })
})

function recordsFrom(startFen: string, sans: string[]): MoveRecord[] {
  const c = new Chess(startFen)
  return sans.map((san) => {
    const m = c.move(san)
    return { san: m.san, from: m.from, to: m.to }
  })
}

describe('auditoria: repetição conforme as regras oficiais', () => {
  const key = (st: GameState) => analyzeMoves(st.moves).fen.split(' ').slice(0, 4).join(' ')

  it('casa de en passant não capturável não torna a posição "diferente" (FIDE 9.2)', () => {
    let s = play(newState(), 'Nf3', 'Nf6', 'e4') // A1
    const a1 = key(s)
    s = play(s, 'Ng8', 'Ng1', 'Nf6', 'Nf3') // A2: mesmo arranjo, sem avanço duplo recente
    assert.equal(key(s), a1)
    assert.equal(analyzeMoves(s.moves).claim.threefold, false)
    s = play(s, 'Ng8', 'Ng1', 'Nf6', 'Nf3') // A3
    assert.equal(key(s), a1)
    assert.equal(analyzeMoves(s.moves).claim.threefold, true, 'terceira ocorrência da mesma posição')
  })

  it('en passant ilegal por cravada horizontal não conta como direito de captura (FEN)', () => {
    const c = new Chess('7k/8/8/K2pP2r/8/8/8/8 w - d6 0 1')
    assert.equal(c.moves().includes('exd6'), false)
    assert.equal(c.fen().split(' ')[3], '-', 'fen() só informa en passant legal')
  })

  it('correção da Fase 1: a repetição tripla é reivindicável na 3ª ocorrência mesmo se a 1ª tinha en passant só no papel', () => {
    // O chess.js acusa a repetição só na 4ª ocorrência nesse caso (hash conta o en passant pseudolegal);
    // pela FIDE 9.2 e pela contagem do app é na 3ª.
    const start = '7k/8/8/K2pP2r/8/8/8/8 w - d6 0 1'
    const cycle = ['Ka4', 'Kg8', 'Ka5', 'Kh8']
    const one = replay(recordsFrom(start, cycle), 4, start)
    assert.equal(one.repetitions, 2)
    assert.equal(analyzeChess(one.chess, one.repetitions).claim.threefold, false)

    const two = replay(recordsFrom(start, [...cycle, ...cycle]), 8, start)
    assert.equal(two.repetitions, 3)
    assert.equal(analyzeChess(two.chess, two.repetitions).claim.threefold, true)
    // documenta o desvio da biblioteca: se um dia o upstream corrigir, este alerta avisa
    assert.equal(two.chess.isThreefoldRepetition(), false, 'chess.js ainda conta o en passant pseudolegal')

    const three = replay(recordsFrom(start, [...cycle, ...cycle, ...cycle]), 12, start)
    assert.equal(three.repetitions, 4)
    assert.equal(three.chess.isThreefoldRepetition(), true)
  })
})

describe('auditoria: material insuficiente (casos de fronteira)', () => {
  // cor das casas: a1 é escura; casa escura quando (coluna 0-7 + fileira 1-8) é ímpar
  const table: Array<[string, string, boolean]> = [
    ['K x K', '8/8/8/4k3/8/8/4K3/8 w - - 0 1', true],
    ['K+C x K', '8/8/8/4k3/8/8/4KN2/8 w - - 0 1', true],
    ['K+B x K', '8/8/8/4k3/8/8/4KB2/8 w - - 0 1', true],
    ['K+B+B (c1 e a3, ambos escuros) x K', '8/8/8/4k3/8/B7/4K3/2B5 w - - 0 1', true],
    ['K+B+B (c1 escura, d1 clara) x K: mate é possível', '8/8/8/4k3/8/8/4K3/2BB4 w - - 0 1', false],
    ['K+C+C x K: mate só com ajuda do adversário, não é posição morta', '8/8/8/4k3/8/8/4KNN1/8 w - - 0 1', false],
    ['K+B x K+B, mesma cor', '8/8/4b3/4k3/8/8/4K3/5B2 w - - 0 1', true],
    ['K+B x K+B, cores opostas', '8/8/3b4/4k3/8/8/4K3/5B2 w - - 0 1', false],
    ['K+C x K+C', '8/8/4n3/4k3/8/8/4KN2/8 w - - 0 1', false],
    ['K+C x K+B', '8/8/4b3/4k3/8/8/4KN2/8 w - - 0 1', false],
    ['K+B+B x K+B, os três em casas escuras', '8/8/3b4/4k3/8/B7/4K3/2B5 w - - 0 1', true],
    ['K+B+B escuros x K+B claro', '8/8/4b3/4k3/8/B7/4K3/2B5 w - - 0 1', false],
    ['K+T x K', '8/8/8/4k3/8/8/4KR2/8 w - - 0 1', false],
    ['K+P x K', '8/8/8/4k3/8/8/4KP2/8 w - - 0 1', false],
  ]
  for (const [name, fen, expected] of table) {
    it(name, () => {
      const out = analyzeChess(new Chess(fen)).outcome
      assert.equal(out?.reason === 'insufficient-material', expected)
    })
  }
})
