// Minimal vitest-compatible shim over node:test, covering only the matchers the chess.js suite uses.
const nodeTest = require('node:test')
const assert = require('node:assert/strict')

const isObj = (v) => v !== null && typeof v === 'object'
const safe = (v) => { try { return typeof v === 'bigint' ? v + 'n' : JSON.stringify(v) } catch { return String(v) } }

function equals(a, b) {
  if (Object.is(a, b)) return true
  if (typeof a !== typeof b || !isObj(a) || !isObj(b)) return false
  if (Array.isArray(a) !== Array.isArray(b)) return false
  if (Array.isArray(a)) return a.length === b.length && a.every((x, i) => equals(x, b[i]))
  const ka = Object.keys(a).filter((k) => a[k] !== undefined)
  const kb = Object.keys(b).filter((k) => b[k] !== undefined)
  return ka.length === kb.length && ka.every((k) => Object.prototype.hasOwnProperty.call(b, k) && equals(a[k], b[k]))
}

function matches(actual, expected) {
  if (!isObj(expected)) return Object.is(actual, expected)
  if (!isObj(actual)) return false
  if (Array.isArray(expected)) return Array.isArray(actual) && actual.length === expected.length && expected.every((e, i) => matches(actual[i], e))
  return Object.keys(expected).every((k) => matches(actual[k], expected[k]))
}

function expect(actual) {
  const build = (neg) => {
    const check = (pass, what) => {
      if (neg ? pass : !pass) {
        throw new assert.AssertionError({ message: `expected ${safe(actual)} ${neg ? 'not ' : ''}${what}` })
      }
    }
    const thrower = (arg) => {
      let threw = false
      let err
      try { actual() } catch (e) { threw = true; err = e }
      let ok = threw
      if (threw && typeof arg === 'string') ok = String(err && err.message).includes(arg)
      else if (threw && arg instanceof RegExp) ok = arg.test(String(err && err.message))
      check(ok, `toThrow(${arg === undefined ? '' : String(arg)})`)
    }
    return {
      toBe: (e) => check(Object.is(actual, e), `toBe ${safe(e)}`),
      toEqual: (e) => check(equals(actual, e), `toEqual ${safe(e)}`),
      toStrictEqual: (e) => check(equals(actual, e), `toStrictEqual ${safe(e)}`),
      toMatchObject: (e) => check(matches(actual, e), `toMatchObject ${safe(e)}`),
      toContain: (e) => check(typeof actual === 'string' ? actual.includes(e) : Array.from(actual).includes(e), `toContain ${safe(e)}`),
      toContainEqual: (e) => check(Array.from(actual).some((x) => equals(x, e)), `toContainEqual ${safe(e)}`),
      toHaveLength: (n) => check(actual.length === n, `toHaveLength ${n}`),
      toBeNull: () => check(actual === null, 'toBeNull'),
      toBeDefined: () => check(actual !== undefined, 'toBeDefined'),
      toBeUndefined: () => check(actual === undefined, 'toBeUndefined'),
      toBeTruthy: () => check(!!actual, 'toBeTruthy'),
      toBeFalsy: () => check(!actual, 'toBeFalsy'),
      toThrow: thrower,
      toThrowError: thrower,
      // chai-style: expect(x).to.have.members([...]) (same elements, any order)
      to: {
        get not() { return build(!neg).to },
        have: (() => {
          const members = (e) => {
            const a = Array.from(actual)
            check(a.length === e.length && e.every((x) => a.some((y) => equals(x, y))) && a.every((y) => e.some((x) => equals(x, y))), `to.have.members ${safe(e)}`)
          }
          return { members, deep: { members } } // equals() is already a deep comparison
        })(),
      },
    }
  }
  const api = build(false)
  api.not = build(true)
  return api
}

// test.each(table)(name, fn): rows that are objects are passed whole, arrays are spread.
const each = (table) => (name, fn) =>
  table.forEach((row, i) => {
    const label = typeof name === 'string' && /\$\w+/.test(name) && !Array.isArray(row)
      ? name.replace(/\$(\w+)/g, (_, k) => String(row[k]))
      : `${name} [${i}]`
    nodeTest.it(label, () => (Array.isArray(row) ? fn(...row) : fn(row)))
  })
const testFn = Object.assign((...a) => nodeTest.it(...a), { each })

module.exports = { describe: nodeTest.describe, it: testFn, test: testFn, beforeEach: nodeTest.beforeEach, expect }
